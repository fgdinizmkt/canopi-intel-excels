/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  Layers, 
  TrendingUp, 
  Users, 
  ArrowUpRight, 
  ArrowRight, 
  Plus, 
  Activity,
  ShieldCheck,
  RefreshCw,
  ChevronRight,
  LayoutDashboard
} from 'lucide-react';
import { Card, Badge, Button } from '../components/ui';

export const ABXOrchestration: React.FC = () => {
  return (
    <div className="space-y-6 animate-in fade-in duration-500 max-w-[1400px] mx-auto">
      {/* Hero Section */}
      <div className="bg-brand p-10 rounded-[32px] text-white relative overflow-hidden shadow-xl shadow-brand/10">
        <div className="absolute top-0 right-0 w-1/3 h-full opacity-20 pointer-events-none">
          <svg viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
            <circle cx="100" cy="100" r="40" stroke="currentColor" strokeWidth="2" />
            <circle cx="100" cy="100" r="60" stroke="currentColor" strokeWidth="1" strokeDasharray="4 4" />
            <circle cx="60" cy="60" r="10" fill="currentColor" />
            <circle cx="140" cy="60" r="10" fill="currentColor" />
            <circle cx="140" cy="140" r="10" fill="currentColor" />
            <circle cx="60" cy="140" r="10" fill="currentColor" />
            <path d="M60 60 L140 140" stroke="currentColor" strokeWidth="1" />
            <path d="M140 60 L60 140" stroke="currentColor" strokeWidth="1" />
          </svg>
        </div>
        
        <div className="relative z-10 max-w-2xl">
          <Badge className="bg-white/20 text-white border-none mb-4 px-3 py-1 text-[9px] font-bold tracking-widest uppercase">
            FRAMEWORK ORQUESTRAÇÃO
          </Badge>
          <h1 className="text-4xl font-bold mb-4 tracking-tight leading-tight">
            A Experiência Coordenada da Conta
          </h1>
          <p className="text-base text-white/90 leading-relaxed font-medium max-w-xl">
            ABX é a abordagem focada em coordenar a experiência da conta ao longo da jornada. Não é apenas marketing; é a sincronia entre dados, vendas e sucesso do cliente para criar relevância ininterrupta.
          </p>
        </div>
      </div>

      {/* KPI Cards - More Compact */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-5 border-none shadow-sm hover:shadow-md transition-all bg-white">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2 bg-blue-50 rounded-xl">
              <TrendingUp className="w-5 h-5 text-blue-600" />
            </div>
            <Badge className="bg-orange-50 text-orange-600 border-none text-[10px] font-bold">+12% vs mês ant.</Badge>
          </div>
          <div className="space-y-0.5">
            <h3 className="text-3xl font-bold text-slate-900">142</h3>
            <p className="text-xs font-bold text-slate-800">Contas em Jornada Ativa</p>
            <p className="text-[10px] text-slate-400 leading-tight mt-1">
              Accounts com sinal de intenção alta nos últimos 7 dias.
            </p>
          </div>
        </Card>

        <Card className="p-5 border-none shadow-sm hover:shadow-md transition-all bg-white">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2 bg-slate-50 rounded-xl">
              <Users className="w-5 h-5 text-slate-400" />
            </div>
            <Badge className="bg-blue-50 text-blue-600 border-none text-[10px] font-bold">Saudável</Badge>
          </div>
          <div className="space-y-0.5">
            <h3 className="text-3xl font-bold text-slate-900">84%</h3>
            <p className="text-xs font-bold text-slate-800">Alta Profundidade Relacional</p>
            <p className="text-[10px] text-slate-400 leading-tight mt-1">
              Contas com mais de 5 stakeholders engajados simultaneamente.
            </p>
          </div>
        </Card>

        <Card className="p-5 border-none shadow-sm hover:shadow-md transition-all bg-white">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2 bg-orange-50 rounded-xl">
              <ArrowUpRight className="w-5 h-5 text-orange-600" />
            </div>
            <Badge className="bg-orange-50 text-orange-600 border-none text-[10px] font-bold">R$ 2.4M</Badge>
          </div>
          <div className="space-y-0.5">
            <h3 className="text-3xl font-bold text-slate-900">26</h3>
            <p className="text-xs font-bold text-slate-800">Oportunidade de Expansão</p>
            <p className="text-[10px] text-slate-400 leading-tight mt-1">
              Clientes atuais com gaps de solução identificados via IA.
            </p>
          </div>
        </Card>
      </div>

      {/* Journey Progression Section */}
      <div className="space-y-4">
        <div className="flex justify-between items-center px-1">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-brand" />
            <h2 className="text-lg font-bold text-slate-900">Jornada da Conta (Distribuição Real-time)</h2>
          </div>
          <button className="text-xs font-bold text-brand hover:underline flex items-center gap-1">
            Ver detalhes do Funil <ChevronRight className="w-3 h-3" />
          </button>
        </div>

        <div className="grid grid-cols-4 gap-1">
          {[
            { label: 'DESCOBERTA', value: '412', color: 'bg-blue-400', bg: 'bg-slate-50' },
            { label: 'ENGAJAMENTO', value: '142', color: 'bg-blue-600', bg: 'bg-blue-50' },
            { label: 'EXPANSÃO', value: '26', color: 'bg-white', bg: 'bg-blue-600', textColor: 'text-white' },
            { label: 'RETENÇÃO', value: '89', color: 'bg-blue-400', bg: 'bg-slate-900', textColor: 'text-white' }
          ].map((stage, i) => (
            <div key={i} className={`p-6 ${stage.bg} first:rounded-l-2xl last:rounded-r-2xl border-r border-white/10 last:border-none`}>
              <p className={`text-[9px] font-bold ${stage.textColor || 'text-slate-400'} tracking-widest mb-4 uppercase`}>{stage.label}</p>
              <p className={`text-3xl font-bold mb-6 ${stage.textColor || 'text-slate-900'}`}>{stage.value}</p>
              <div className={`h-1.5 w-full ${stage.textColor ? 'bg-white/20' : 'bg-slate-200'} rounded-full overflow-hidden`}>
                <div className={`${stage.color} h-full rounded-full`} style={{ width: '40%' }}></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Relationship Evolution */}
        <Card className="lg:col-span-3 p-8 border-none shadow-sm bg-white">
          <div className="flex items-center gap-2 mb-8">
            <Users className="w-5 h-5 text-brand" />
            <h2 className="text-lg font-bold text-slate-900">Evolução do Relacionamento</h2>
          </div>

          <div className="space-y-8">
            <div className="flex justify-between items-end">
              <div>
                <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-1">Força do Relacionamento (AI Score)</p>
                <div className="flex items-baseline gap-1">
                  <span className="text-4xl font-bold text-slate-900">7.8</span>
                  <span className="text-slate-400 font-bold text-lg">/ 10</span>
                </div>
              </div>
              <div className="flex flex-col items-end gap-2">
                <Badge className="bg-blue-50 text-blue-600 border-none font-bold text-[10px]">+0.4 este mês</Badge>
                <div className="flex gap-1 items-end h-6 bg-blue-50/50 p-1 rounded">
                  {[30, 50, 40, 70, 60].map((h, i) => (
                    <div key={i} className={`w-1.5 rounded-t-sm ${i === 3 ? 'bg-blue-600' : 'bg-blue-300'}`} style={{ height: `${h}%` }}></div>
                  ))}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-8">
              <div className="space-y-3">
                <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">COBERTURA DE STAKEHOLDERS</p>
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className={`h-1.5 flex-1 rounded-full ${i < 3 ? 'bg-blue-600' : 'bg-slate-200'}`}></div>
                  ))}
                </div>
              </div>
              <div className="space-y-3">
                <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">72% META DE PENETRAÇÃO</p>
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className={`h-1.5 flex-1 rounded-full ${i < 4 ? 'bg-blue-600' : 'bg-slate-200'}`}></div>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 pt-4 border-t border-slate-50">
              <div className="flex -space-x-2">
                {[1, 2, 3].map((i) => (
                  <img 
                    key={i}
                    src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${i + 20}`} 
                    className="w-8 h-8 rounded-full border-2 border-white bg-slate-100"
                    alt="User"
                    referrerPolicy="no-referrer"
                  />
                ))}
                <div className="w-8 h-8 rounded-full border-2 border-white bg-slate-50 flex items-center justify-center text-[9px] font-bold text-slate-400">
                  +14
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Recommended Plays */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex justify-between items-center px-1">
            <h2 className="text-lg font-bold text-slate-900">Plays ABX Recomendados</h2>
          </div>

          <div className="space-y-3 relative">
            {[
              { 
                title: 'Play de Expansão: Cloud Migration', 
                desc: 'Identificado gap na conta TechCorp S.A.',
                icon: TrendingUp,
                color: 'blue'
              },
              { 
                title: 'Play Sponsor: Mudança de Liderança', 
                desc: 'Novo CTO em Innova Retail. Iniciar jornada de recepção.',
                icon: ShieldCheck,
                color: 'orange'
              },
              { 
                title: 'Play Reengajamento: Inatividade 30d', 
                desc: 'Reaquecer com conteúdo de Benchmarking p/ Global Logistics.',
                icon: RefreshCw,
                color: 'slate'
              }
            ].map((play, i) => (
              <Card key={i} className="p-4 border-none shadow-sm hover:shadow-md transition-all flex gap-4 items-center bg-white group">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${play.color === 'blue' ? 'bg-blue-50' : play.color === 'orange' ? 'bg-orange-50' : 'bg-slate-50'}`}>
                  <play.icon className={`w-5 h-5 ${play.color === 'blue' ? 'text-blue-600' : play.color === 'orange' ? 'text-orange-600' : 'text-slate-600'}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-xs font-bold text-slate-900 truncate">{play.title}</h4>
                  <p className="text-[10px] text-slate-500 line-clamp-1">{play.desc}</p>
                </div>
              </Card>
            ))}
            
            <button className="absolute -right-2 top-1/2 -translate-y-1/2 w-10 h-10 bg-brand rounded-xl flex items-center justify-center shadow-lg shadow-brand/30 hover:scale-105 transition-transform z-10">
              <Plus className="w-5 h-5 text-white" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};


