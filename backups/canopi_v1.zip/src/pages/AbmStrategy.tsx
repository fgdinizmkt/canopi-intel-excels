"use client";

import React, { useState, useMemo } from 'react';
import { 
  Target, 
  Filter, 
  Plus, 
  ChevronRight, 
  BarChart3, 
  Database, 
  Cpu, 
  Search, 
  CheckCircle2, 
  Loader2, 
  Sparkles,
  Zap,
  Layout,
  Layers,
  Activity,
  Map,
  ShieldCheck,
  Globe,
  PieChart,
  ArrowRight,
  TrendingUp,
  Clock,
  ExternalLink,
  Bot,
  BadgeCheck,
  Users,
  Box,
  MessageSquare,
  FileText,
  Mail,
  Calendar,
  Eye,
  ArrowUpRight,
  MoreVertical,
  Flag,
  Maximize2,
  TrendingDown,
  BarChart,
  Building2,
  Cloud,
  BrainCircuit,
  Settings2,
  History,
  MousePointer2,
  Smartphone,
  Share2,
  Bell,
  CheckCircle,
  AlertCircle,
  FileSearch,
  ZapOff,
  Crosshair
} from 'lucide-react';
import { Card, Badge, Button, Modal } from '../components/ui';
import { motion, AnimatePresence } from 'framer-motion';

// --- MOCK DATA ---

const benchmarks = [
  { id: 'reach', label: 'Target Account Reach', val: '72%', trend: '+15%', elite: 'Elite: 70%+', desc: 'Alcance total do comitê de compra' },
  { id: 'winrate', label: 'ABM Win Rate', val: '48%', trend: '+12%', elite: 'Elite: 45%+', desc: 'Taxa de fechamento vs marketing trad.' },
  { id: 'roi', label: 'Account-Based ROI', val: '432%', trend: '+5%', elite: 'Elite: 400%+', desc: 'Retorno financeiro por real investido' },
  { id: 'prog', label: 'Progression Rate', val: '42%', trend: '+8%', elite: 'Elite: 40%+', desc: 'Contas que avançaram no funil' },
];

const abmAccounts = [
  { id: '1',  initials: 'GB', name: 'Global Bank S.A.',   vertical: 'Financeiro',  fitScore: 9.8, status: 'HOT',       engagement: 92, mqa: true  },
  { id: '2',  initials: 'MN', name: 'Manufatura Norte',   vertical: 'Manufactura', fitScore: 7.5, status: 'PLAYBOOK',  engagement: 45, mqa: false },
  { id: '3',  initials: 'SB', name: 'ScalePay Brasil',    vertical: 'Financeiro',  fitScore: 9.2, status: 'MAPEANDO',  engagement: 88, mqa: true  },
  { id: '4',  initials: 'IH', name: 'Innova Health',      vertical: 'Saúde',       fitScore: 8.9, status: 'HOT',       engagement: 74, mqa: true  },
  { id: '5',  initials: 'AB', name: 'AlphaBank S.A.',     vertical: 'Financeiro',  fitScore: 9.0, status: 'HOT',       engagement: 85, mqa: true  },
  { id: '6',  initials: 'FP', name: 'FinPay Brasil',      vertical: 'Fintech',     fitScore: 8.7, status: 'HOT',       engagement: 80, mqa: true  },
  { id: '7',  initials: 'TM', name: 'TelecomMax',         vertical: 'Telecom',     fitScore: 8.4, status: 'MAPEANDO',  engagement: 72, mqa: true  },
  { id: '8',  initials: 'AG', name: 'AgroCloud',          vertical: 'Agronegócio', fitScore: 7.8, status: 'PLAYBOOK',  engagement: 68, mqa: false },
  { id: '9',  initials: 'IB', name: 'InfraBuild',         vertical: 'Construção',  fitScore: 7.2, status: 'MAPEANDO',  engagement: 60, mqa: false },
  { id: '10', initials: 'EC', name: 'EnergyCore',         vertical: 'Energia',     fitScore: 6.8, status: 'WATCH',     engagement: 42, mqa: false },
  { id: '11', initials: 'NS', name: 'NovaSaude',          vertical: 'Saúde',       fitScore: 7.0, status: 'MAPEANDO',  engagement: 55, mqa: false },
  { id: '12', initials: 'PT', name: 'PaperTech Ind.',     vertical: 'Indústria',   fitScore: 6.5, status: 'WATCH',     engagement: 38, mqa: false },
];

// ABM Priority accounts - scatter data: x=Impacto, y=Probabilidade (% de 0-100)
const scatterAccounts = [
  { id: 1,  x: 78, y: 82, label: '10', account: 'Global Bank S.A.',   vertical: 'Financeiro',  tier: 'TIER 1', arr: 'R$ 450k', action: 'Ação 1', risk: 'critical',  actionDesc: 'Reunião executiva + Proposta personalizada Finanças 4.0' },
  { id: 2,  x: 85, y: 88, label: '8',  account: 'ScalePay Brasil',    vertical: 'Financeiro',  tier: 'TIER 1', arr: 'R$ 280k', action: 'Ação 1', risk: 'critical',  actionDesc: 'Sequência de nurturing via LinkedIn + Social Ads 1:1' },
  { id: 3,  x: 62, y: 75, label: '9',  account: 'Innova Health',      vertical: 'Saúde',       tier: 'TIER 1', arr: 'R$ 620k', action: 'Ação 3', risk: 'high',      actionDesc: 'Webinar exclusivo Compliance HealthTech + Follow-up SDR' },
  { id: 4,  x: 90, y: 60, label: '12', account: 'TechInsure Co.',     vertical: 'Seguros',     tier: 'TIER 1', arr: 'R$ 390k', action: 'Ação 1', risk: 'high',      actionDesc: 'Conteúdo de prova social + Relatório ROI personalizado' },
  { id: 5,  x: 50, y: 68, label: '9',  account: 'AgroCloud Latam',    vertical: 'Agronegócio', tier: 'MID',    arr: 'R$ 170k', action: 'Ação 3', risk: 'high',      actionDesc: 'Demo guiada do produto + Parceria de canal' },
  { id: 6,  x: 38, y: 55, label: '10', account: 'Manufatura Norte',   vertical: 'Manufatura',  tier: 'MID',    arr: 'R$ 120k', action: 'Ação 4', risk: 'moderate', actionDesc: 'Relatório de eficiência operacional + Indicação interna' },
  { id: 7,  x: 25, y: 78, label: '10', account: 'EduTech S.A.',       vertical: 'Educação',    tier: 'MID',    arr: 'R$ 95k',  action: 'Ação 4', risk: 'moderate', actionDesc: 'Programa de trial + Parceria acadêmica' },
  { id: 8,  x: 70, y: 42, label: '4',  account: 'RetailMax Brasil',   vertical: 'Varejo',      tier: 'SMB',    arr: 'R$ 55k',  action: 'Ação 2', risk: 'moderate', actionDesc: 'Campanha de reengajamento por e-mail + Ads Remarketing' },
  { id: 9,  x: 55, y: 38, label: '9',  account: 'LogParcel Group',    vertical: 'Logística',   tier: 'SMB',    arr: 'R$ 72k',  action: 'Ação 2', risk: 'low',      actionDesc: 'Sequência de outbound fria com personalização por vertical' },
  { id: 10, x: 18, y: 32, label: '10', account: 'StartupX',           vertical: 'SaaS',        tier: 'SMB',    arr: 'R$ 30k',  action: 'Ação 4', risk: 'low',      actionDesc: 'Inclusão em newsletter + Trial gratuito' },
  { id: 11, x: 42, y: 22, label: '7',  account: 'GovTech MG',        vertical: 'Governo',     tier: 'SMB',    arr: 'R$ 48k',  action: 'Ação 2', risk: 'low',      actionDesc: 'Webinar público + Levantamento de necessidades via BDR' },
  { id: 12, x: 82, y: 28, label: '5',  account: 'MediaGroup Brasil', vertical: 'Mídia',       tier: 'SMB',    arr: 'R$ 42k',  action: 'Ação 2', risk: 'low',      actionDesc: 'Estratégia de conteúdo co-criado + Campanha de influência' },
];

// Hexbin: organic multi-hotspot distribution
const personas = ['CEO / Presidente', 'CFO / Dir. Finanças', 'CTO / Dir. TI', 'CMO / Dir. Mkt', 'COO / Dir. Ops', 'CISO / Seg. Info', 'VP Comercial', 'Head de Produto', 'Gerente de TI', 'Analista Sênior'];
const hexVerticals = ['Financeiro', 'Saúde', 'Manufatura', 'SaaS', 'Logística', 'Varejo', 'Seguros', 'Educação', 'Energia', 'Agroneg.'];

// Organic distribution: manually set hotspot intensities per (row=persona, col=vertical)
// Values 0..1 → color scale
const hexIntensityMap: Record<string, number> = {
  '0,0':0.95, '0,1':0.45, '0,2':0.35, '0,3':0.60, '0,4':0.30, '0,5':0.25, '0,6':0.70, '0,7':0.20, '0,8':0.40, '0,9':0.50,
  '1,0':0.85, '1,1':0.50, '1,2':0.30, '1,3':0.45, '1,4':0.20, '1,5':0.15, '1,6':0.65, '1,7':0.15, '1,8':0.35, '1,9':0.40,
  '2,0':0.55, '2,1':0.75, '2,2':0.60, '2,3':0.90, '2,4':0.55, '2,5':0.80, '2,6':0.40, '2,7':0.50, '2,8':0.30, '2,9':0.35,
  '3,0':0.40, '3,1':0.45, '3,2':0.35, '3,3':0.70, '3,4':0.30, '3,5':0.25, '3,6':0.35, '3,7':0.60, '3,8':0.25, '3,9':0.30,
  '4,0':0.50, '4,1':0.40, '4,2':0.85, '4,3':0.50, '4,4':0.75, '4,5':0.30, '4,6':0.45, '4,7':0.35, '4,8':0.60, '4,9':0.70,
  '5,0':0.60, '5,1':0.80, '5,2':0.45, '5,3':0.55, '5,4':0.35, '5,5':0.90, '5,6':0.55, '5,7':0.30, '5,8':0.25, '5,9':0.20,
  '6,0':0.70, '6,1':0.50, '6,2':0.40, '6,3':0.55, '6,4':0.45, '6,5':0.35, '6,6':0.80, '6,7':0.40, '6,8':0.50, '6,9':0.60,
  '7,0':0.45, '7,1':0.60, '7,2':0.70, '7,3':0.80, '7,4':0.50, '7,5':0.40, '7,6':0.35, '7,7':0.75, '7,8':0.30, '7,9':0.45,
  '8,0':0.30, '8,1':0.35, '8,2':0.55, '8,3':0.45, '8,4':0.65, '8,5':0.30, '8,6':0.40, '8,7':0.50, '8,8':0.85, '8,9':0.55,
  '9,0':0.20, '9,1':0.25, '9,2':0.40, '9,3':0.35, '9,4':0.50, '9,5':0.20, '9,6':0.30, '9,7':0.40, '9,8':0.60, '9,9':0.75,
};
const getHexCellColor = (intensity: number): string => {
  if (intensity >= 0.90) return '#c0392b';
  if (intensity >= 0.80) return '#e74c3c';
  if (intensity >= 0.70) return '#e67e22';
  if (intensity >= 0.60) return '#f39c12';
  if (intensity >= 0.50) return '#f9ca24';
  if (intensity >= 0.40) return '#a8e6cf';
  if (intensity >= 0.30) return '#27ae60';
  if (intensity >= 0.20) return '#2ecc71';
  return '#1abc9c';
};
const channelByIntensity = (v: number) => {
  if (v >= 0.80) return 'LinkedIn Ads 1:1 + Outreach Executive';
  if (v >= 0.60) return 'Email Marketing + Webinar Exclusivo';
  if (v >= 0.40) return 'Social Ads + Conteúdo Educacional';
  return 'Newsletter + Trial Gratuito';
};

const entryPlays = [
  { id: 'p1', title: 'Relatório Setorial Customizado', desc: 'Envio de PDF personalizado com comparativo de eficácia para C-Levels do setor Industrial.', efficacy: 88, icon: <FileText className="w-5 h-5" /> },
  { id: 'p2', title: 'Webinar de Mesa Redonda', desc: 'Convite exclusivo para diretores financeiros de Fintechs Mid-market discutirem Open Banking.', efficacy: 72, icon: <Users className="w-5 h-5" /> },
  { id: 'p3', title: 'Campanha Social Ads 1:1', desc: 'Ads altamente focados em dor específica de segurança de dados para o Tier 1 de HealthTech.', efficacy: 94, icon: <Layout className="w-5 h-5" /> },
];

const verticalClusters = [
  { id: 'v1', name: 'Manufatura Enterprise', count: 32, playbook: 'Eficiência Operacional 4.0', val: 85, health: 'Estável' },
  { id: 'v2', name: 'Fintech Mid-market', count: 48, playbook: 'Scaling High Velocity', val: 72, health: 'Em Queda' },
  { id: 'v3', name: 'HealthTech Tier 1', count: 15, playbook: 'Compliance & Privacy First', val: 94, health: 'Crítico' },
  { id: 'v4', name: 'AgroTech Expansion', count: 21, playbook: 'Penetração em Mercados de Alto Potencial', val: 67, health: 'Estável' },
];

const journeyTimeline = [
  { stage: 'Awareness', count: 142, status: 'complete', color: 'bg-blue-400' },
  { stage: 'Engagement', count: 85, status: 'active', color: 'bg-indigo-500' },
  { stage: 'MQA', count: 24, status: 'pending', color: 'bg-emerald-500' },
  { stage: 'Opportunity', count: 12, status: 'pending', color: 'bg-amber-500' },
  { stage: 'Win', count: 5, status: 'pending', color: 'bg-emerald-600' },
];



// ---- 6 ABM HEATMAPS DATA ----
const abmHeatmapAccounts = [
  // name, vertical, importance(y), icp, crm, verticalPot, contacts, fit, budget(R$k mapeado da base ABM)
  { id: 1,  name: 'AlphaBank S.A.',    vertical: 'Financeiro',  imp: 88, icp: 87, crm: 45, vp: 82, ct: 78, ft: 84, budget: 420 },
  { id: 2,  name: 'NovaSaude',         vertical: 'Saúde',       imp: 74, icp: 72, crm: 80, vp: 68, ct: 55, ft: 70, budget: 185 },
  { id: 3,  name: 'PaperTech Ind.',    vertical: 'Indústria',   imp: 60, icp: 58, crm: 62, vp: 75, ct: 90, ft: 55, budget: 90  },
  { id: 4,  name: 'MobilityPro',       vertical: 'Mobilidade',  imp: 50, icp: 45, crm: 35, vp: 60, ct: 40, ft: 48, budget: 60  },
  { id: 5,  name: 'AgroCloud',         vertical: 'Agronegócio', imp: 65, icp: 78, crm: 70, vp: 85, ct: 30, ft: 60, budget: 210 },
  { id: 6,  name: 'TelecomMax',        vertical: 'Telecom',     imp: 80, icp: 82, crm: 90, vp: 55, ct: 65, ft: 77, budget: 310 },
  { id: 7,  name: 'SeguraVida',        vertical: 'Seguros',     imp: 55, icp: 55, crm: 48, vp: 52, ct: 72, ft: 50, budget: 130 },
  { id: 8,  name: 'RetailTech',        vertical: 'Varejo',      imp: 42, icp: 38, crm: 55, vp: 40, ct: 35, ft: 38, budget: 45  },
  { id: 9,  name: 'EduVision',         vertical: 'Educação',   imp: 35, icp: 30, crm: 28, vp: 45, ct: 20, ft: 32, budget: 30  },
  { id: 10, name: 'InfraBuild',        vertical: 'Construção',  imp: 70, icp: 65, crm: 60, vp: 70, ct: 85, ft: 62, budget: 160 },
  { id: 11, name: 'FinPay Brasil',     vertical: 'Fintech',     imp: 85, icp: 90, crm: 85, vp: 78, ct: 60, ft: 88, budget: 380 },
  { id: 12, name: 'EnergyCore',        vertical: 'Energia',     imp: 62, icp: 50, crm: 42, vp: 90, ct: 48, ft: 56, budget: 250 },
];
const abmHeatmapCriteria = [
  {
    id: 'icp',
    title: 'ICP Score',
    subtitle: 'Aderência ao Perfil Ideal de Cliente',
    xLabel: 'SCORE ICP',
    yLabel: 'IMPORTÂNCIA ESTRATÉGICA',
    note: 'Eixo X = aderência ao perfil ideal de cliente. Eixo Y = importância estratégica da conta. Contas no quadrante superior direito são prioridade máxima de abordagem.',
    desc: (a: typeof abmHeatmapAccounts[0]) =>
      `ICP ${a.icp}% — ${a.icp >= 75 ? 'Alta aderência ao perfil ideal. Prioridade máxima de abordagem.' : a.icp >= 50 ? 'Aderência moderada. Qualificar antes de avançar.' : 'Fora do perfil. Manter em nurturing passivo.'}`,
    scoreKey: 'icp' as const,
  },
  {
    id: 'crm',
    title: 'Engajamento no CRM',
    subtitle: 'Histórico de interações e atividade registrada',
    xLabel: 'NÍVEL DE ENGAJAMENTO',
    yLabel: 'IMPORTÂNCIA ESTRATÉGICA',
    note: 'Eixo X = volume de interações registradas no CRM (calls, e-mails, demos). Eixo Y = relevância da conta. Contas acima de 70% de engajamento devem ser ativadas via SDR imediatamente.',
    desc: (a: typeof abmHeatmapAccounts[0]) =>
      `Engajamento ${a.crm}% — ${a.crm >= 70 ? 'Conta ativa com múltiplas interações. Acionar SDR imediatamente.' : a.crm >= 45 ? 'Engajamento médio. Intensificar conteúdo 1:1.' : 'Conta fria. Iniciar reativação com campanha de reconhecimento.'}`,
    scoreKey: 'crm' as const,
  },
  {
    id: 'vp',
    title: 'Potencial da Vertical',
    subtitle: 'Mercado endereçável e sinergia com nosso portfólio',
    xLabel: 'POTENCIAL DE MERCADO',
    yLabel: 'IMPORTÂNCIA ESTRATÉGICA',
    note: 'Cada bolha representa uma vertical de mercado. Eixo X = potencial de expansão e TAM da vertical. Eixo Y = peso estratégico. Verticais no quadrante quente indicam onde concentrar budget de marketing.',
    desc: (a: typeof abmHeatmapAccounts[0]) =>
      `Vertical ${a.vp}% — ${a.vp >= 75 ? 'Vertical de alta tração. Há benchmarks e cases aplicáveis.' : a.vp >= 50 ? 'Potencial moderado. Desenvolver case específico.' : 'Vertical emergente. Avaliar ROI antes de investir.'}`,
    scoreKey: 'vp' as const,
  },
  {
    id: 'ct',
    title: 'Contatos Mapeados',
    subtitle: 'Profundidade e qualidade dos relacionamentos na conta',
    xLabel: 'COBERTURA DE CONTATOS',
    yLabel: 'IMPORTÂNCIA ESTRATÉGICA',
    note: 'Eixo X = cobertura do DMU (Decision Making Unit) — percentual de stakeholders mapeados na conta. Priorize contas estratégicas com baixa cobertura: maior gap, maior oportunidade de expansão.',
    desc: (a: typeof abmHeatmapAccounts[0]) =>
      `Contatos ${a.ct}% — ${a.ct >= 75 ? 'DMU bem mapeado. Champion e Decisor identificados.' : a.ct >= 45 ? 'Contatos parciais. Expandir rede via LinkedIn Sales Nav.' : 'Poucos contatos. Estratégia de entrada via eventos ou parceiros.'}`,
    scoreKey: 'ct' as const,
  },
  {
    id: 'ft',
    title: 'Fit com a Canopi',
    subtitle: 'Alinhamento tecnológico, cultural e de timing',
    xLabel: 'FIT CANOPI',
    yLabel: 'IMPORTÂNCIA ESTRATÉGICA',
    note: 'Eixo X = alinhamento da conta com o stack tecnológico, maturidade analítica e timing comercial da Canopi. Contas com fit alto e importância alta são candidatas a fast-track no pipeline.',
    desc: (a: typeof abmHeatmapAccounts[0]) =>
      `Fit ${a.ft}% — ${a.ft >= 75 ? 'Fit excelente. Stack tecnológica e maturidade analítica alinhadas.' : a.ft >= 50 ? 'Fit parcial. Identificar gaps e propor roadmap gradual.' : 'Fit baixo. Considerar parceiros integradores antes de avançar.'}`,
    scoreKey: 'ft' as const,
  },
  {
    id: 'avg',
    title: 'Média Geral',
    subtitle: 'Score consolidado dos 5 critérios — ranking ABM',
    xLabel: 'SCORE CONSOLIDADO',
    yLabel: 'IMPORTÂNCIA ESTRATÉGICA',
    note: 'Score composto = média de ICP, Engajamento CRM, Potencial da Vertical, Contatos Mapeados e Fit Canopi. Contas acima de 72% são classificadas como TOP TIER e recebem SDR + AE dedicados.',
    desc: (a: typeof abmHeatmapAccounts[0]) => {
      const avg = Math.round((a.icp + a.crm + a.vp + a.ct + a.ft) / 5);
      return `Média ${avg}% — ${avg >= 72 ? 'TOP TIER: Alocar SDR + AE dedicados. Iniciar play imediatamente.' : avg >= 55 ? 'MID TIER: Incluir em sequência nurturing avançada.' : 'LOW TIER: Manter em watch list e reavaliar em 90 dias.'}`;
    },
    scoreKey: 'avg' as const,
  },
];
// Helper to get score for 'avg'
const getHmScore = (acc: typeof abmHeatmapAccounts[0], key: string): number => {
  if (key === 'avg') return Math.round((acc.icp + acc.crm + acc.vp + acc.ct + acc.ft) / 5);
  return acc[key as keyof typeof acc] as number;
};

export const ABMStrategy: React.FC<{subPage?: string}> = ({ subPage }) => {
  const [modalOpen, setModalOpen] = useState(false);
  const [modalData, setModalData] = useState<{ title: string; content: React.ReactNode; size?: 'sm' | 'md' | 'lg' | 'xl' } | null>(null);
  const [hmTooltip, setHmTooltip] = useState<{ criterionId: string; x: number; y: number; displayName: string; name: string; vertical: string; score: number; desc: string } | null>(null);
  // Sliders reativos
  const [icpThreshold, setIcpThreshold] = useState(70);
  const [icpWeights, setIcpWeights] = useState({ receita: 30, stack: 25, equipe: 20, setor: 25 });
  const [budgetAlloc, setBudgetAlloc] = useState({ financeiro: 35, saude: 20, agro: 18, telecom: 15, outros: 12 });
  const totalBudget = 480; // R$480k budget total ABM mapeado da base
  // Score ICP ponderado pelos pesos configurados (normalizado 0-100)
  const getWeightedIcp = (acc: typeof abmHeatmapAccounts[0]) => {
    const base = acc.icp;
    const weightedDelta = ((icpWeights.receita - 30) * 0.4 + (icpWeights.stack - 25) * 0.3 + (icpWeights.equipe - 20) * 0.2 + (icpWeights.setor - 25) * 0.3) / 10;
    return Math.max(1, Math.min(99, Math.round(base + weightedDelta)));
  };

  const openDetailedModal = (type: string, data: any) => {
    let content;
    switch(type) {
      case 'ACCOUNT':
        content = (
          <div className="space-y-6 animate-in fade-in duration-300">
            <div className="flex items-center gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-100">
              <div className="w-12 h-12 rounded-xl bg-white border border-slate-200 flex items-center justify-center font-bold text-blue-600 text-lg shadow-sm">
                {data.initials}
              </div>
              <div>
                <h4 className="text-base font-bold text-slate-900">{data.name}</h4>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{data.industry} • TIER 1</p>
              </div>
              <Badge variant="emerald" className="ml-auto">HOT ACCOUNT</Badge>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-white border border-slate-100 rounded-2xl shadow-sm">
                <p className="text-[10px] font-bold text-slate-400 uppercase mb-3 flex items-center gap-2"><Users className="w-3 h-3"/> Comitê de Compra</p>
                <div className="space-y-3">
                  {[{ role: 'Champion', name: 'Ana Souza', status: 'Engajada' }, { role: 'Buyer', name: 'Marcos Reais', status: 'Conectado' }, { role: 'Influencer', name: 'Carla Dias', status: 'Pendente' }].map((p, i) => (
                    <div key={i} className="flex items-center justify-between">
                      <span className="text-xs font-medium text-slate-600">{p.role}</span>
                      <span className="text-[10px] font-bold text-slate-900 px-2 py-0.5 bg-slate-50 rounded border border-slate-100">{p.status}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="p-4 bg-white border border-slate-100 rounded-2xl shadow-sm">
                <p className="text-[10px] font-bold text-slate-400 uppercase mb-3 flex items-center gap-2"><Settings2 className="w-3 h-3"/> Tech Match</p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="blue" className="bg-blue-50 text-blue-600 border-none text-[9px]">AWS Cloud</Badge>
                  <Badge variant="blue" className="bg-indigo-50 text-indigo-600 border-none text-[9px]">Salesforce CRM</Badge>
                  <Badge variant="blue" className="bg-purple-50 text-purple-600 border-none text-[9px]">Hubspot Inbound</Badge>
                </div>
              </div>
            </div>
            <div className="p-4 bg-slate-900 text-white rounded-2xl shadow-lg">
              <div className="flex justify-between items-center mb-4">
                <h5 className="text-xs font-bold uppercase tracking-widest flex items-center gap-2"><Zap className="w-3 h-3 fill-amber-400 text-amber-400"/> Next Best Action</h5>
                <Badge variant="slate" className="bg-white/10 text-white border-none text-[8px]">IA SUGGESTION</Badge>
              </div>
              <p className="text-sm font-medium mb-4 text-slate-300">Enviar convite para mesa redonda de C-Levels sobre Finanças 4.0. Ana Souza (Champion) demonstrou interesse em posts relacionados ontem.</p>
              <Button size="sm" className="w-full bg-blue-600 border-none font-bold">Agendar via SDR</Button>
            </div>
          </div>
        );
        setModalData({ title: `Estratégia: ${data.name}`, content, size: 'lg' });
        break;
      case 'METRIC':
        content = (
          <div className="space-y-6">
             <div className="p-6 bg-blue-50 rounded-2xl border border-blue-100">
                <p className="text-[10px] font-bold text-blue-600 uppercase mb-1">{data.label}</p>
                <p className="text-3xl font-bold text-slate-900">{data.val}</p>
                <p className="text-xs text-slate-500 font-medium mt-1">{data.desc}</p>
             </div>
             <div className="grid grid-cols-2 gap-4">
                <div className="space-y-4">
                   <h5 className="text-[10px] font-bold text-slate-400 uppercase">vs Métodos Tradicionais</h5>
                   <div className="flex items-end gap-3 h-32">
                      <div className="w-10 bg-slate-200 rounded-t-lg h-12 flex items-center justify-center"><span className="text-[10px] -rotate-90 font-bold">Trad.</span></div>
                      <div className="w-10 bg-blue-600 rounded-t-lg h-[90%] flex items-center justify-center"><span className="text-[10px] -rotate-90 font-bold text-white">ABM</span></div>
                   </div>
                   <p className="text-[10px] font-bold text-emerald-600 uppercase">↑ 2.4x Eficiência</p>
                </div>
                <div className="space-y-2">
                   <h5 className="text-[10px] font-bold text-slate-400 uppercase">Benchmark Elite</h5>
                   <p className="text-sm font-bold text-slate-900">{data.elite}</p>
                </div>
            </div>
          </div>
        );
        setModalData({ title: `Analítico: ${data.label}`, content, size: 'md' });
        break;
      case 'PLAY':
         content = (
            <div className="space-y-6">
               <div className="flex items-center gap-6 p-6 bg-slate-50 rounded-2xl border border-slate-200">
                  <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-sm text-blue-600">{data.icon}</div>
                  <div>
                     <h4 className="text-lg font-bold text-slate-900">{data.title}</h4>
                     <p className="text-xs text-slate-500 font-medium tracking-tight">Eficácia Estimada: {data.efficacy}%</p>
                  </div>
               </div>
               <div className="p-5 bg-white border border-slate-200 rounded-2xl space-y-4 shadow-sm">
                  <h5 className="text-[10px] font-bold text-slate-400 uppercase">Roteiro de Ativação</h5>
                  {[
                     { step: '1', task: 'Validar lista de contatos no LinkedIn Sales Navigator' },
                     { step: '2', task: 'Disparar e-mail 1:1 personalizado com o Champion' },
                     { step: '3', task: 'Ativar Social Ads focados no cluster Manufatura' },
                     { step: '4', task: 'Ligação de agendamento via BDR/SDR' }
                  ].map((s, i) => (
                     <div key={i} className="flex gap-4 items-start pb-4 border-b border-slate-50 last:border-none">
                        <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px] font-bold">{s.step}</div>
                        <p className="text-xs text-slate-700 font-medium leading-relaxed">{s.task}</p>
                     </div>
                  ))}
               </div>
               <Button className="w-full bg-slate-900 text-white rounded-xl py-6 font-bold uppercase shadow-lg shadow-slate-900/10">Orquestrar Agora</Button>
            </div>
         );
         setModalData({ title: `Playbook: ${data.title}`, content });
         break;
      case 'CLUSTER':
         content = (
            <div className="space-y-6">
               <div className="flex justify-between items-start p-6 bg-blue-600 rounded-2xl text-white shadow-xl shadow-blue-500/20">
                  <div>
                     <h4 className="text-xl font-bold uppercase tracking-tight">{data.name}</h4>
                     <p className="text-[10px] font-bold opacity-80 mt-1">{data.count} CONTAS ATIVAS NO CLUSTER</p>
                  </div>
                  <Badge variant="slate" className="bg-white/20 text-white border-none text-[9px] font-bold uppercase">{data.health}</Badge>
               </div>
               <div className="p-6 bg-white border border-slate-200 rounded-2xl shadow-sm space-y-4">
                  <h5 className="text-[10px] font-bold text-slate-400 uppercase">Resumo de Atividade</h5>
                  <div className="grid grid-cols-2 gap-4">
                     <div className="p-4 bg-slate-50 rounded-xl">
                        <p className="text-[9px] font-bold text-slate-400 uppercase mb-1">Engajamento Médio</p>
                        <p className="text-lg font-bold text-slate-900">{data.val}%</p>
                     </div>
                     <div className="p-4 bg-slate-50 rounded-xl">
                        <p className="text-[9px] font-bold text-slate-400 uppercase mb-1">Novas MQAs (7d)</p>
                        <p className="text-lg font-bold text-emerald-600">+4</p>
                     </div>
                  </div>
                  <div className="pt-4">
                     <p className="text-[10px] font-bold text-slate-500 uppercase flex items-center gap-2 mb-3"><Layout className="w-3 h-3"/> Playbook Ativo</p>
                     <p className="text-sm font-bold text-slate-900 bg-slate-50 p-3 rounded-lg border border-slate-100">{data.playbook}</p>
                  </div>
               </div>
               <Button className="w-full bg-blue-600 text-white rounded-xl py-6 font-bold uppercase shadow-lg shadow-blue-500/20">Expandir Cluster</Button>
            </div>
         );
         setModalData({ title: `Análise de Cluster: ${data.name}`, content });
         break;
      case 'PRIORITY_POINT':
        const riskColors: Record<string, string> = { critical: 'bg-red-600', high: 'bg-orange-500', moderate: 'bg-yellow-400', low: 'bg-green-500' };
        const riskLabels: Record<string, string> = { critical: 'Crítico', high: 'Alto Risco', moderate: 'Moderado', low: 'Baixo Risco' };
        const riskTexts: Record<string, string> = { critical: 'text-red-600', high: 'text-orange-500', moderate: 'text-yellow-600', low: 'text-green-600' };
        content = (
          <div className="space-y-6">
            <div className="flex items-center justify-between p-5 bg-slate-50 rounded-2xl border border-slate-100">
              <div>
                <h4 className="text-base font-bold text-slate-900 uppercase tracking-tight">{data.account}</h4>
                <p className="text-[10px] font-bold text-slate-400 uppercase mt-1 tracking-widest">{data.vertical} • {data.tier}</p>
              </div>
              <div className={`${riskColors[data.risk]} text-white text-[9px] font-bold uppercase px-3 py-1.5 rounded-lg`}>{riskLabels[data.risk]}</div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="p-4 bg-white border border-slate-100 rounded-2xl text-center shadow-sm">
                <p className="text-[9px] font-bold text-slate-400 uppercase mb-1">ARR Potencial</p>
                <p className="text-sm font-bold text-slate-900">{data.arr}</p>
              </div>
              <div className="p-4 bg-white border border-slate-100 rounded-2xl text-center shadow-sm">
                <p className="text-[9px] font-bold text-slate-400 uppercase mb-1">Probabilidade</p>
                <p className={`text-sm font-bold ${riskTexts[data.risk]}`}>{data.y}%</p>
              </div>
              <div className="p-4 bg-white border border-slate-100 rounded-2xl text-center shadow-sm">
                <p className="text-[9px] font-bold text-slate-400 uppercase mb-1">Impacto Score</p>
                <p className="text-sm font-bold text-slate-900">{data.x}/100</p>
              </div>
            </div>
            <div className="p-5 bg-white border border-slate-200 rounded-2xl space-y-3 shadow-sm">
              <h5 className="text-[10px] font-bold text-slate-400 uppercase flex items-center gap-2"><Zap className="w-3 h-3 text-amber-500" /> Ação Recomendada ({data.action})</h5>
              <p className="text-sm font-medium text-slate-700 leading-relaxed">{data.actionDesc}</p>
            </div>
            <div className="p-5 bg-slate-900 text-white rounded-2xl space-y-4">
              <h5 className="text-[10px] font-bold uppercase tracking-widest flex items-center gap-2"><BrainCircuit className="w-3 h-3 fill-blue-400 text-blue-400" /> Próximos Passos (IA)</h5>
              <div className="space-y-3">
                {['Mapear Comitê de Compra (DMU) no LinkedIn Sales Navigator', 'Criar sequência de abordagem personalizada por perfil de cargo', 'Ativar play de intenção com conteúdo setorial exclusivo'].map((step, i) => (
                  <div key={i} className="flex gap-3 items-start">
                    <div className="w-5 h-5 rounded-full bg-blue-600 flex items-center justify-center text-[9px] font-bold shrink-0 mt-0.5">{i + 1}</div>
                    <p className="text-xs text-slate-300 font-medium leading-relaxed">{step}</p>
                  </div>
                ))}
              </div>
              <Button size="sm" className="w-full bg-blue-600 border-none font-bold mt-2">Lançar Sequência de Ativação</Button>
            </div>
          </div>
        );
        setModalData({ title: `Análise de Conta: ${data.account}`, content, size: 'md' });
        break;
      case 'HEX_CELL':
        const scoreDisplay = data.score as number;
        const hexRisk = scoreDisplay >= 80 ? 'Muito Alta' : scoreDisplay >= 60 ? 'Moderada' : scoreDisplay >= 40 ? 'Baixa' : 'Muito Baixa';
        const hexColor = scoreDisplay >= 80 ? '#c0392b' : scoreDisplay >= 60 ? '#f39c12' : scoreDisplay >= 40 ? '#27ae60' : '#1abc9c';
        const contentTypes: Record<string, string[]> = {
          'LinkedIn Ads 1:1 + Outreach Executive': ['Case Study Executivo', 'Convite para Evento Exclusivo', 'Insights de Mercado Personalizados'],
          'Email Marketing + Webinar Exclusivo': ['Newsletter Setorial', 'Webinar Temático', 'Relatório de Benchmark'],
          'Social Ads + Conteúdo Educacional': ['Article LinkedIn', 'Infográfico de Setor', 'Mini-curso Online'],
          'Newsletter + Trial Gratuito': ['Trial Freemium', 'Post Educacional', 'White Paper'],
        };
        const contents = contentTypes[data.channel as string] || ['Conteúdo genérico'];
        content = (
          <div className="space-y-6">
            <div className="flex items-center justify-between p-5 rounded-2xl" style={{ backgroundColor: hexColor + '15', border: `1px solid ${hexColor}30` }}>
              <div>
                <h4 className="text-base font-bold text-slate-900 uppercase">{data.persona}</h4>
                <p className="text-[10px] font-bold text-slate-500 uppercase mt-1">Vertical: {data.vertical}</p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold" style={{ color: hexColor }}>{scoreDisplay}%</p>
                <p className="text-[9px] font-bold text-slate-400 uppercase">Sinergia {hexRisk}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-white border border-slate-100 rounded-2xl shadow-sm">
                <p className="text-[9px] font-bold text-slate-400 uppercase mb-2">Canal Principal</p>
                <p className="text-xs font-bold text-slate-800">{data.channel}</p>
              </div>
              <div className="p-4 bg-white border border-slate-100 rounded-2xl shadow-sm">
                <p className="text-[9px] font-bold text-slate-400 uppercase mb-2">Abordagem</p>
                <p className="text-xs font-bold text-slate-800">{scoreDisplay >= 60 ? '1:1 Personalizada' : 'Nurturing Escalável'}</p>
              </div>
            </div>
            <div className="p-5 bg-white border border-slate-200 rounded-2xl space-y-3">
              <h5 className="text-[10px] font-bold text-slate-400 uppercase">Conteúdos Recomendados</h5>
              {contents.map((c, i) => (
                <div key={i} className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl">
                  <div className="w-4 h-4 rounded-full flex items-center justify-center shrink-0" style={{ backgroundColor: hexColor }}>
                    <CheckCircle2 className="w-3 h-3 text-white" />
                  </div>
                  <span className="text-xs font-medium text-slate-700">{c}</span>
                </div>
              ))}
            </div>
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
              <p className="text-[9px] font-bold text-slate-400 uppercase mb-2">Estimativa de Tempo de Resposta</p>
              <p className="text-sm font-bold text-slate-900">{scoreDisplay >= 80 ? '3-7 dias' : scoreDisplay >= 60 ? '7-14 dias' : scoreDisplay >= 40 ? '14-30 dias' : '+30 dias'}</p>
            </div>
            <Button className="w-full bg-slate-900 text-white rounded-xl py-3 font-bold uppercase">Criar Sequência para Esta Combinação</Button>
          </div>
        );
        setModalData({ title: `Sinergia: ${data.persona} x ${data.vertical}`, content, size: 'md' });
        break;
      default:
        // Categóricas ricas baseadas no "type"
        const typeStr = String(type);
        const isForm = ['GOAL', 'OPP', 'SEG', 'CREATE_CLUSTER', 'CRM_ALERT', 'FUND', 'ALERT', 'CRM_UPDATE', 'ASSIGN', 'CANOPI', 'RSVP', 'PERF'].includes(typeStr);
        const isList = ['EXPORT', 'SYNC', 'HIST', 'SHARE', 'AUDIENCE', 'LOOKALIKE', 'REFINE_IA', 'ENR_IA', 'SEND_SALES', 'SS', 'REP'].includes(typeStr);
        const isCamp = ['BATCH', 'CAMP', 'SEQ', 'CAMP_REACT', 'EMAIL', 'CLEVEL_PLAY', 'PLAY', 'NEW_PLAY', 'SDR', 'AE'].includes(typeStr);
        const isAgenda = ['SCHED', 'ACTIVITY', 'CONNECT', 'DEMO', 'EVENT', 'EXEC_SYNC', 'GIFT'].includes(typeStr);
        
        let ui;

        if (isForm) {
            ui = (
              <div className="space-y-4">
                 <div className="p-4 bg-slate-50 border border-slate-100 rounded-xl relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-3xl -mr-10 -mt-10"></div>
                    <h5 className="text-sm font-bold text-slate-800">{data.label || 'Nova Entrada'}</h5>
                    <p className="text-[10px] text-slate-500 mt-1">Preencha os dados necessários para o registro sistêmico.</p>
                 </div>
                 <div className="space-y-3">
                    <div>
                      <label className="text-[9px] font-bold text-slate-400 uppercase mb-1 block">Nome / Referência</label>
                      <input type="text" className="w-full border border-slate-200 rounded-lg px-3 py-2 text-xs focus:border-blue-500 focus:ring-1 focus:ring-blue-500" defaultValue={data.account?.name || data.label} />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                       <div>
                         <label className="text-[9px] font-bold text-slate-400 uppercase mb-1 block">Proprietário (Owner)</label>
                         <select className="w-full border border-slate-200 rounded-lg px-3 py-2 text-xs bg-white"><option>SDR Team Lead</option><option>AE Enterprise</option></select>
                       </div>
                       <div>
                         <label className="text-[9px] font-bold text-slate-400 uppercase mb-1 block">Prioridade</label>
                         <select className="w-full border border-slate-200 rounded-lg px-3 py-2 text-xs bg-white"><option>ALTA</option><option>NORMAL</option></select>
                       </div>
                    </div>
                    <div>
                      <label className="text-[9px] font-bold text-slate-400 uppercase mb-1 block">Anotações Adicionais</label>
                      <textarea className="w-full border border-slate-200 rounded-lg px-3 py-2 text-xs h-20" placeholder="Insira o contexto ou instruções..."></textarea>
                    </div>
                 </div>
              </div>
            );
        } else if (isList) {
            ui = (
              <div className="space-y-4">
                 <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-xl flex items-center justify-between">
                    <div>
                      <h5 className="text-sm font-bold text-emerald-800">Preview de Dados (Sync)</h5>
                      <p className="text-[10px] text-emerald-600 mt-0.5">74 registros selecionados para {data.label}</p>
                    </div>
                    <Button size="sm" className="bg-emerald-600 text-white font-bold text-[9px] uppercase px-4 h-7">Validar Schema</Button>
                 </div>
                 <div className="border border-slate-200 rounded-xl overflow-hidden">
                    <table className="w-full text-left">
                       <thead className="bg-slate-50">
                          <tr><th className="px-3 py-2 text-[9px] font-bold text-slate-500 uppercase">Objeto</th><th className="px-3 py-2 text-[9px] font-bold text-slate-500 uppercase">Match Score</th><th className="px-3 py-2 text-[9px] font-bold text-slate-500 uppercase text-right">Ação</th></tr>
                       </thead>
                       <tbody className="divide-y divide-slate-100 text-[10px] font-medium text-slate-700">
                          <tr><td className="px-3 py-2 font-bold">{data.account?.name || 'Globex Corporation'}</td><td className="px-3 py-2 text-emerald-600">98% Fit</td><td className="px-3 py-2 text-right"><span className="bg-emerald-100 text-emerald-700 px-1.5 py-0.5 rounded">Update</span></td></tr>
                          <tr><td className="px-3 py-2 font-bold">Acme Corp South</td><td className="px-3 py-2 text-blue-600">85% Fit</td><td className="px-3 py-2 text-right"><span className="bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded">Insert</span></td></tr>
                          <tr><td className="px-3 py-2 font-bold">Initech Financial</td><td className="px-3 py-2 text-blue-600">77% Fit</td><td className="px-3 py-2 text-right"><span className="bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded">Insert</span></td></tr>
                       </tbody>
                    </table>
                 </div>
                 <div className="flex items-center gap-2 p-3 bg-amber-50 rounded-lg border border-amber-100">
                    <AlertCircle className="w-4 h-4 text-amber-500 shrink-0"/>
                    <p className="text-[9px] text-amber-700 font-medium">Atenção: A sincronização com Salesforce/Outreach consome tokens da API da Canopi.</p>
                 </div>
              </div>
            );
        } else if (isCamp) {
            ui = (
              <div className="space-y-4">
                 <div className="text-center p-6 border border-slate-100 rounded-xl bg-gradient-to-br from-slate-50 to-white shadow-sm relative overflow-hidden">
                    <Zap className="w-12 h-12 text-blue-200 absolute -right-2 -bottom-2" />
                    <div className="w-10 h-10 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-3"><Mail className="w-5 h-5"/></div>
                    <h5 className="text-base font-bold text-slate-800 tracking-tight">{data.label || 'Lançar Playbook'}</h5>
                    <p className="text-[10px] text-slate-500 mt-1 max-w-xs mx-auto">Esta ação ativará a orquestração multicanal (Email, LinkedIn, Ads) para as contas em lote.</p>
                 </div>
                 <div className="px-4 py-3 bg-slate-50 rounded-xl border border-slate-200">
                    <p className="text-[9px] font-bold text-slate-400 uppercase mb-3">Linha do Tempo de Ativação (Preview)</p>
                    <div className="space-y-3 relative before:absolute before:inset-0 before:ml-[11px] before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-slate-200 before:to-transparent">
                       <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                          <div className="flex items-center justify-center w-6 h-6 rounded-full border border-white bg-slate-100 group-[.is-active]:bg-blue-600 text-slate-500 group-[.is-active]:text-emerald-50 shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 text-[8px] font-bold z-10">D0</div>
                          <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-3 rounded-xl border border-blue-100 bg-white shadow-[0_4px_12px_rgba(0,0,0,0.03)]"><p className="text-[10px] font-bold text-slate-800">Email 1: Introdução Executiva</p></div>
                       </div>
                       <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                          <div className="flex items-center justify-center w-6 h-6 rounded-full border border-white bg-slate-100 text-slate-500 shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 text-[8px] font-bold z-10">D3</div>
                          <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-3 rounded-xl border border-slate-100 bg-white"><p className="text-[10px] font-bold text-slate-600">LinkedIn: Visualização do SDR</p></div>
                       </div>
                       <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                          <div className="flex items-center justify-center w-6 h-6 rounded-full border border-white bg-slate-100 text-slate-500 shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 text-[8px] font-bold z-10">D5</div>
                          <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-3 rounded-xl border border-slate-100 bg-white"><p className="text-[10px] font-bold text-slate-600">Task CRM: Ligar para Champion</p></div>
                       </div>
                    </div>
                 </div>
              </div>
            );
        } else if (isAgenda) {
            ui = (
              <div className="space-y-4">
                 <div className="p-4 bg-indigo-50 border border-indigo-100 rounded-xl">
                    <h5 className="text-sm font-bold text-indigo-900 border-b border-indigo-200 pb-2 mb-2">{data.label || 'Agendamento e Agenda'}</h5>
                    <div className="grid grid-cols-7 gap-1 mt-4">
                       {['D','S','T','Q','Q','S','S'].map((d,i)=><div key={i} className="text-center text-[8px] font-bold text-indigo-400">{d}</div>)}
                       {[...Array(30)].map((_,i)=><div key={i} className={`h-8 rounded flex items-center justify-center text-[10px] font-medium ${i===14 ? 'bg-indigo-600 text-white font-bold shadow-md' : i>10 && i<18 ? 'bg-indigo-100/50 text-indigo-800 hover:bg-indigo-200 cursor-pointer' : 'text-slate-400'}`}>{i+1}</div>)}
                    </div>
                 </div>
                 <div className="space-y-2">
                    <p className="text-[9px] font-bold text-slate-400 uppercase">Horários Disponíveis (15 Nov)</p>
                    <div className="flex gap-2">
                       <Button size="sm" variant="outline" className="flex-1 text-[10px]">10:00 AM</Button>
                       <Button size="sm" className="flex-1 bg-indigo-100 text-indigo-700 hover:bg-indigo-200 border-none font-bold text-[10px]">14:30 PM</Button>
                       <Button size="sm" variant="outline" className="flex-1 text-[10px]">16:00 PM</Button>
                    </div>
                 </div>
              </div>
            );
        } else {
            // Dashboard / Análise Genérica para o restante
            ui = (
              <div className="space-y-4">
                 <div className="p-5 bg-slate-900 rounded-xl relative overflow-hidden text-white shadow-xl">
                    <BarChart3 className="absolute right-[-20%] top-[-20%] w-48 h-48 opacity-10" />
                    <h5 className="text-lg font-bold tracking-tight mb-1">{data.label || 'Relatório Analítico'}</h5>
                    <p className="text-xs text-slate-400 font-medium max-w-[80%]">Visualização macro de gaps e engajamento da conta ou lote selecionado.</p>
                 </div>
                 <div className="grid grid-cols-3 gap-3">
                    <div className="p-3 bg-slate-50 border border-slate-100 rounded-lg text-center">
                       <p className="text-[9px] font-bold text-slate-400 uppercase mb-1">Média Hit-Rate</p>
                       <p className="text-lg font-black text-slate-800">42%</p>
                    </div>
                    <div className="p-3 bg-slate-50 border border-slate-100 rounded-lg text-center">
                       <p className="text-[9px] font-bold text-slate-400 uppercase mb-1">CAC Est.</p>
                       <p className="text-lg font-black text-rose-500">R$3k</p>
                    </div>
                    <div className="p-3 bg-slate-50 border border-slate-100 rounded-lg text-center">
                       <p className="text-[9px] font-bold text-slate-400 uppercase mb-1">Velocidade</p>
                       <p className="text-lg font-black text-emerald-500">+12d</p>
                    </div>
                 </div>
                 <div className="p-4 border border-slate-200 rounded-xl">
                    <p className="text-[9px] font-bold text-slate-700 uppercase mb-3 text-center">Desempenho em 30 dias</p>
                    <div className="flex items-end justify-between h-16 pt-2">
                       {[30, 45, 20, 60, 85, 50, 95].map((v, i) => (
                          <div key={i} className="w-[10%] bg-blue-100 rounded-t-sm hover:bg-blue-300 transition-colors relative group">
                             <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 bg-slate-800 text-white text-[8px] px-1 py-0.5 rounded opacity-0 group-hover:opacity-100">{v}</div>
                             <div className="w-full bg-blue-500 rounded-t-sm" style={{ height: `${v}%` }}></div>
                          </div>
                       ))}
                    </div>
                 </div>
              </div>
            );
        }

        content = (
          <div className="space-y-6">
            {ui}
            <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
               <Button variant="ghost" size="sm" className="font-bold text-[10px] uppercase text-slate-500" onClick={() => setModalOpen(false)}>Cancelar</Button>
               <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-[10px] uppercase px-6 border-none shadow-md shadow-blue-500/20" onClick={() => setModalOpen(false)}>{isForm ? 'Salvar Configuração' : isCamp ? 'Iniciar Sequência' : isAgenda ? 'Confirmar Agendamento' : 'Confirmar Ação Sistêmica'}</Button>
            </div>
          </div>
        );
        setModalData({ title: `${data.label || type}`, content, size: isList || isCamp ? 'lg' as any : 'md' as any });
        break;
    }
    setModalOpen(true);
  };

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-32 max-w-[1700px] mx-auto font-sans text-slate-900">
      
      {/* 1. HERO - Discreet & Powerful */}
      <div className="bg-white border border-slate-200 rounded-[32px] p-8 flex flex-col md:flex-row justify-between items-center gap-8 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 p-10 opacity-[0.03] pointer-events-none">
           <Activity className="w-64 h-64" />
        </div>
        <div className="flex items-center gap-6">
           <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-blue-500/20">
              <Target className="w-8 h-8" />
           </div>
           <div>
              <div className="flex items-center gap-2 mb-1">
                 <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Estratégia Comercial</span>
                 <ChevronRight className="w-3 h-3 text-slate-300" />
                 <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest">Growth Framework</span>
              </div>
              <h1 className="text-3xl font-bold text-slate-900 tracking-tight leading-none uppercase">Estratégia ABM</h1>
              <p className="text-xs text-slate-500 font-medium mt-2 max-w-lg leading-relaxed">
                 Orquestração de contas-alvo baseada em fit firmográfico, tecnográfico e sinais de intenção em tempo real. Painel unificado de inteligência e plays táticos.
              </p>
           </div>
        </div>
        <div className="flex items-center gap-4 bg-slate-50 p-3 rounded-2xl border border-slate-100 z-10">
           <div className="px-6 py-2 text-center border-r border-slate-200">
              <p className="text-[9px] font-bold text-slate-400 uppercase">Target Accounts</p>
              <p className="text-lg font-bold text-slate-900">142</p>
           </div>
           <div className="px-6 py-2 text-center">
              <p className="text-[9px] font-bold text-slate-400 uppercase">Health Score</p>
              <p className="text-lg font-bold text-emerald-600">8.4/10</p>
           </div>
           <Button size="sm" className="bg-slate-900 hover:bg-black text-white rounded-xl font-bold px-6 border-none" onClick={() => openDetailedModal('TAL_CONFIG', {})}>Refinar TAL</Button>
        </div>
      </div>

      {/* 2. ELITE BENCHMARKS GRID */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {benchmarks.map((b, i) => (
          <motion.div 
            key={i} 
            whileHover={{ y: -5 }}
            onClick={() => openDetailedModal('METRIC', b)}
            className="bg-white p-6 rounded-[28px] border border-slate-100 shadow-sm relative group cursor-pointer hover:border-blue-400 transition-all"
          >
             <div className="flex justify-between items-center mb-4">
                <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center text-slate-400 group-hover:bg-blue-50 group-hover:text-blue-600 transition-all">
                   <BarChart3 className="w-5 h-5" />
                </div>
                <Badge variant="emerald" className="text-[9px] font-bold border-none uppercase">{b.trend}</Badge>
             </div>
             <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">{b.label}</p>
             <h3 className="text-3xl font-bold text-slate-900 mb-2">{b.val}</h3>
             <p className="text-[9px] font-bold text-slate-400 uppercase tracking-tight">{b.elite}</p>
          </motion.div>
        ))}
      </div>

      {/* GRID PRINCIPAL: TAL (7/12) + Funil ABM + Clusters (5/12) */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">

        {/* LEFT: TAL TABLE compact */}
        <div className="xl:col-span-7">
          <div className="bg-white rounded-[32px] border border-slate-200 shadow-sm overflow-hidden h-fit">
            <div className="px-6 py-4 border-b border-slate-50 flex justify-between items-center bg-slate-50/10">
              <div>
                <h3 className="text-base font-bold text-slate-900 uppercase">Universo de Contas (TAL)</h3>
                <p className="text-[10px] text-slate-500 font-medium mt-0.5">Interações, Fit e Maturidade do Pipeline ABM</p>
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant="ghost" className="text-[10px] font-bold text-slate-400 uppercase"><Filter className="w-3 h-3 mr-1.5"/>Filtros</Button>
                <Button size="sm" className="bg-blue-600 text-white rounded-xl text-[10px] font-bold uppercase py-1.5 px-4 border-none shadow-lg shadow-blue-500/20">Nova Conta</Button>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-100">
                    <th className="pl-6 py-3 text-[9px] font-bold text-slate-500 uppercase">Account / Vertical</th>
                    <th className="px-3 py-3 text-[9px] font-bold text-slate-500 uppercase text-center">Score</th>
                    <th className="px-3 py-3 text-[9px] font-bold text-slate-500 uppercase text-center">MQA</th>
                    <th className="px-3 py-3 text-[9px] font-bold text-slate-500 uppercase">Engaj.</th>
                    <th className="pr-6 py-3 text-[9px] font-bold text-slate-500 uppercase text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {abmAccounts.map(acc => (
                    <tr key={acc.id} className="hover:bg-slate-50/50 transition-colors group cursor-pointer" onClick={() => openDetailedModal('ACCOUNT', acc)}>
                      <td className="pl-6 py-3.5">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-xl bg-white border border-slate-200 flex items-center justify-center font-bold text-slate-400 text-xs group-hover:border-blue-400 transition-all shadow-sm">{acc.initials}</div>
                          <div><p className="text-xs font-bold text-slate-800">{acc.name}</p><p className="text-[9px] text-slate-400 font-bold uppercase tracking-tight">{acc.vertical}</p></div>
                        </div>
                      </td>
                      <td className="px-3 py-3.5 text-center"><span className="text-xs font-bold text-slate-900">{acc.fitScore}</span></td>
                      <td className="px-3 py-3.5 text-center">
                        {acc.mqa ? (<div className="flex justify-center"><BadgeCheck className="w-4 h-4 text-emerald-500" /></div>) : (<div className="flex justify-center"><Circle className="w-4 h-4 text-slate-200" /></div>)}
                      </td>
                      <td className="px-3 py-3.5">
                        <div className="flex items-center gap-1.5">
                          <div className="h-1.5 w-14 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
                            <div className={`h-full ${acc.engagement > 80 ? 'bg-emerald-500' : 'bg-blue-500'}`} style={{ width: `${acc.engagement}%` }}></div>
                          </div>
                          <span className="text-[9px] font-bold text-slate-900">{acc.engagement}%</span>
                        </div>
                      </td>
                      <td className="pr-6 py-3.5 text-right"><Badge variant={acc.status === 'HOT' ? 'emerald' : 'slate'} className="text-[8px] font-bold uppercase border-none">{acc.status}</Badge></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* RIGHT: Funil ABM + Clusterização */}
        <div className="xl:col-span-5 space-y-5">
          {/* FUNIL ABM */}
          <div className="bg-white p-6 rounded-[28px] border border-slate-200 shadow-sm space-y-5">
            <div className="flex justify-between items-center">
              <h3 className="text-sm font-bold text-slate-900 uppercase">Jornada de Contas (Funil ABM)</h3>
              <Badge variant="slate" className="bg-slate-50 text-slate-400 border-none font-bold text-[8px] uppercase tracking-tighter">PROGRESSION</Badge>
            </div>
            <div className="space-y-3.5">
              {journeyTimeline.map((j, i) => (
                <div key={i} className="flex items-center gap-4">
                  <div className="w-20 text-[9px] font-bold text-slate-400 uppercase tracking-widest">{j.stage}</div>
                  <div className="flex-1 relative h-2.5 bg-slate-100 rounded-full overflow-hidden border border-slate-50">
                    <motion.div initial={{ width: 0 }} animate={{ width: `${(j.count / journeyTimeline[0].count) * 100}%` }} transition={{ duration: 1.5, delay: i * 0.1 }} className={`h-full ${j.color} shadow-sm`}></motion.div>
                  </div>
                  <div className="w-8 text-right text-[11px] font-bold text-slate-900">{j.count}</div>
                </div>
              ))}
              <div className="pt-3 border-t border-slate-50 flex justify-between items-center">
                <p className="text-[9px] font-bold text-slate-400 uppercase">Velocity Index ABM</p>
                <div className="flex items-center gap-1.5 text-emerald-600 font-bold text-[10px] uppercase"><TrendingUp className="w-3 h-3" /> 15% ACCEL.</div>
              </div>
            </div>
          </div>

          {/* CLUSTERIZAÇÃO */}
          <div className="bg-white rounded-[28px] border border-slate-200 shadow-sm overflow-hidden">
            <div className="px-6 pt-5 pb-4 bg-slate-50/20 border-b border-slate-50 flex justify-between items-center">
              <h3 className="text-sm font-bold text-slate-900 uppercase flex items-center gap-2"><Box className="w-4 h-4 text-blue-600" /> Clusterização ABM</h3>
              <Button variant="ghost" size="sm" className="text-[9px] font-bold text-slate-400 uppercase">+ Novo</Button>
            </div>
            <div className="p-5 space-y-3">
              {verticalClusters.map((c, i) => (
                <div key={i} className="p-4 bg-white border border-slate-100 rounded-2xl shadow-sm hover:border-blue-300 transition-all cursor-pointer group" onClick={() => openDetailedModal('CLUSTER', c)}>
                  <div className="flex justify-between items-center mb-2">
                    <div><p className="text-[11px] font-bold text-slate-800 group-hover:text-blue-600 transition-colors uppercase tracking-tight">{c.name}</p><p className="text-[8px] font-bold text-slate-400 uppercase mt-0.5">{c.count} CONTAS</p></div>
                    <Badge variant={c.health === 'Estável' ? 'blue' : c.health === 'Em Queda' ? 'amber' : 'red'} className="text-[7px] font-bold border-none uppercase">{c.health}</Badge>
                  </div>
                  <div className="h-1.5 w-full bg-slate-50 rounded-full overflow-hidden mb-2 border border-slate-100"><div className="h-full bg-blue-600" style={{ width: `${c.val}%` }}></div></div>
                  <div className="flex justify-between items-center">
                    <span className="text-[8px] font-bold text-slate-400 uppercase">Efficiency: {c.val}%</span>
                    <span className="text-[8px] font-bold text-blue-600 uppercase flex items-center gap-1 group-hover:translate-x-1 transition-transform">Playbook <ArrowRight className="w-2 h-2" /></span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      {/* FIM GRID PRINCIPAL */}

            {/* ===== 6 HEATMAPS DE CONTAS ABM + ACTION CARDS ===== */}
            {(() => {
              const orderedCriteria = ['avg','icp','ct','ft','crm','vp'];
              const criteriaMap = Object.fromEntries(abmHeatmapCriteria.map(c => [c.id, c]));

              // Sorted accounts by avg for ranking
              const ranked = [...abmHeatmapAccounts].sort((a,b) => {
                const avgA = Math.round((a.icp+a.crm+a.vp+a.ct+a.ft)/5);
                const avgB = Math.round((b.icp+b.crm+b.vp+b.ct+b.ft)/5);
                return avgB - avgA;
              });

              const qualifiedIcp = abmHeatmapAccounts.filter(a => getWeightedIcp(a) >= icpThreshold);
              const hotCrm = abmHeatmapAccounts.filter(a => a.crm >= 70);
              const coldCrm = abmHeatmapAccounts.filter(a => a.crm < 45);

              const MiniActions = ({ actions }: { actions: { icon: React.ReactNode; label: string; onClick: () => void }[] }) => (
                <div className="pt-3 border-t border-slate-100 grid grid-cols-3 gap-1.5 mt-auto">
                  {actions.map((a, i) => (
                    <button key={i} onClick={a.onClick}
                      className="flex flex-col items-center gap-1 p-2 rounded-xl hover:bg-slate-50 border border-slate-100 hover:border-blue-200 transition-all text-center group">
                      <span className="text-slate-400 group-hover:text-blue-500 transition-colors">{a.icon}</span>
                      <span className="text-[7px] font-bold text-slate-400 group-hover:text-blue-500 uppercase tracking-wide leading-tight">{a.label}</span>
                    </button>
                  ))}
                </div>
              );

              const actionCards: Record<string, React.ReactNode[]> = {
                avg: [
                  <div key="avg-c1" className="bg-white rounded-[24px] border border-slate-200 shadow-sm p-5 flex flex-col h-full space-y-3">
                    <div className="flex items-center justify-between">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2"><TrendingUp className="w-3 h-3 text-blue-500"/>Ranking ABM</p>
                      <Badge variant="blue" className="text-[8px] border-none bg-blue-50 text-blue-600 font-bold">AO VIVO</Badge>
                    </div>
                    <div className="space-y-1.5">
                      {ranked.slice(0,5).map((acc, i) => {
                        const avg = Math.round((acc.icp+acc.crm+acc.vp+acc.ct+acc.ft)/5);
                        const tier = avg >= 72 ? { label:'TOP', cls:'bg-red-100 text-red-600' } : avg >= 55 ? { label:'MID', cls:'bg-amber-100 text-amber-600' } : { label:'LOW', cls:'bg-slate-100 text-slate-500' };
                        return (
                          <div key={acc.id} className="flex items-center gap-2 p-2 rounded-xl hover:bg-slate-50 transition-colors cursor-pointer" onClick={() => openDetailedModal('ACCOUNT', acc)}>
                            <span className="text-[10px] font-bold text-slate-300 w-4">{i+1}</span>
                            <div className="flex-1 min-w-0"><p className="text-[10px] font-bold text-slate-800 truncate">{acc.name}</p></div>
                            <span className={`text-[8px] font-bold px-2 py-0.5 rounded-md ${tier.cls}`}>{tier.label}</span>
                            <span className="text-[11px] font-black text-slate-700">{avg}%</span>
                          </div>
                        );
                      })}
                    </div>
                    <MiniActions actions={[
                      { icon: <FileText className="w-3 h-3"/>, label: 'Exportar CSV', onClick: () => openDetailedModal('EXPORT', { label: 'Ranking ABM' }) },
                      { icon: <Users className="w-3 h-3"/>, label: 'Atribuir AE', onClick: () => openDetailedModal('ASSIGN', { label: 'Atribuição de AE' }) },
                      { icon: <Flag className="w-3 h-3"/>, label: 'Criar Meta', onClick: () => openDetailedModal('GOAL', { label: 'Meta de Pipeline' }) },
                    ]} />
                  </div>,
                  <div key="avg-c2" className="bg-white rounded-[24px] border border-slate-200 shadow-sm p-5 flex flex-col h-full space-y-3">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2"><Zap className="w-3 h-3 text-amber-500"/>Orquestrar em Lote</p>
                    <div className="space-y-2">
                      {[
                        { label:'Ativar TOP TIER', sub:`${ranked.filter(a=>Math.round((a.icp+a.crm+a.vp+a.ct+a.ft)/5)>=72).length} contas prontas`, cls:'bg-red-600 hover:bg-red-700 text-white', icon:<Zap className="w-3 h-3"/>, type:'BATCH_TOP' },
                        { label:'Nurturing MID TIER', sub:`${ranked.filter(a=>{const s=Math.round((a.icp+a.crm+a.vp+a.ct+a.ft)/5);return s>=55&&s<72;}).length} contas em espera`, cls:'bg-amber-500 hover:bg-amber-600 text-white', icon:<Activity className="w-3 h-3"/>, type:'BATCH_MID' },
                        { label:'Watch List LOW TIER', sub:`${ranked.filter(a=>Math.round((a.icp+a.crm+a.vp+a.ct+a.ft)/5)<55).length} contas`, cls:'bg-slate-200 hover:bg-slate-300 text-slate-700', icon:<Clock className="w-3 h-3"/>, type:'BATCH_LOW' },
                      ].map((btn, i) => (
                        <button key={i} onClick={() => openDetailedModal('BATCH', { label: btn.label, type: btn.type })} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all ${btn.cls}`}>
                          {btn.icon}
                          <div><p className="text-[10px] font-bold">{btn.label}</p><p className="text-[8px] opacity-70">{btn.sub}</p></div>
                        </button>
                      ))}
                    </div>
                    <MiniActions actions={[
                      { icon: <ArrowUpRight className="w-3 h-3"/>, label: 'Criar Oport.', onClick: () => openDetailedModal('OPP', { label: 'Nova Oportunidade CRM' }) },
                      { icon: <Calendar className="w-3 h-3"/>, label: 'Agendar', onClick: () => openDetailedModal('SCHED', { label: 'Agendar Revisão de Pipeline' }) },
                      { icon: <Database className="w-3 h-3"/>, label: 'Sync CRM', onClick: () => openDetailedModal('SYNC', { label: 'Sincronizar com Salesforce' }) },
                    ]} />
                  </div>,

                  <div key="avg-c3" className="bg-white rounded-[24px] border border-slate-200 shadow-sm p-5 flex flex-col h-full space-y-3">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2"><Layout className="w-3 h-3 text-indigo-500"/>Playbooks em Execução</p>
                    <div className="space-y-2">
                       {['Expansão Tier 1', 'Reengajamento C-Level', 'Nurturing Mid-Market'].map((p, i) => (
                         <div key={i} className="flex justify-between items-center p-2 bg-slate-50 rounded-lg">
                           <span className="text-[9px] font-bold text-slate-700">{p}</span>
                           <Badge variant="blue" className="text-[7px] border-none">ATIVO</Badge>
                         </div>
                       ))}
                    </div>
                    <button onClick={() => openDetailedModal('NEW_PLAY', { label: 'Novo Playbook de Orquestração' })} className="w-full py-2.5 bg-slate-900 hover:bg-black text-white text-[9px] font-bold uppercase rounded-xl transition-colors mt-2">Explorar Biblioteca de Plays</button>
                    <MiniActions actions={[
                      { icon: <Activity className="w-3 h-3"/>, label: 'Performance', onClick: () => openDetailedModal('PERF', { label: 'Performance de Playbooks' }) },
                      { icon: <Database className="w-3 h-3"/>, label: 'Templates', onClick: () => openDetailedModal('TPL', { label: 'Templates de Sequences' }) },
                      { icon: <Users className="w-3 h-3"/>, label: 'Audiência', onClick: () => openDetailedModal('AUDIENCE', { label: 'Audiência dos Playbooks' }) },
                    ]} />
                  </div>,
                ],
                icp: [
                  <div key="icp-c1" className="bg-white rounded-[24px] border border-slate-200 shadow-sm p-5 flex flex-col h-full space-y-3">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2"><Target className="w-3 h-3 text-blue-500"/>Qualificação ICP</p>
                    <div className="space-y-2">
                      <div>
                        <div className="flex justify-between text-[9px] font-bold text-slate-500 uppercase mb-1">
                          <span>Score mínimo</span>
                          <span className="text-blue-600">≥ {icpThreshold}% — {qualifiedIcp.length} contas</span>
                        </div>
                        <input type="range" min="40" max="95" value={icpThreshold}
                          onChange={e => setIcpThreshold(Number(e.target.value))}
                          className="w-full h-1.5 accent-blue-600 rounded-full cursor-pointer"/>
                      </div>
                      <div className="space-y-1.5">
                        {qualifiedIcp.slice(0,4).map(acc => (
                          <div key={acc.id} className="flex items-center justify-between p-2 bg-blue-50 rounded-lg cursor-pointer hover:bg-blue-100 transition-colors" onClick={() => openDetailedModal('ACCOUNT', acc)}>
                            <span className="text-[9px] font-bold text-slate-700 truncate max-w-[110px]">{acc.name}</span>
                            <span className="text-[10px] font-black text-blue-700">{getWeightedIcp(acc)}%</span>
                          </div>
                        ))}
                        {qualifiedIcp.length === 0 && <p className="text-[9px] text-slate-400 text-center py-2">Nenhuma conta nesse threshold</p>}
                      </div>
                    </div>
                    <button onClick={() => openDetailedModal('EXPORT', { label: `Lista ICP ≥${icpThreshold}%` })} className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-[9px] font-bold uppercase rounded-xl transition-colors">Exportar Lista Qualificada</button>
                    <MiniActions actions={[
                      { icon: <FileSearch className="w-3 h-3"/>, label: 'Segmento', onClick: () => openDetailedModal('SEG', { label: 'Segmento ICP' }) },
                      { icon: <Database className="w-3 h-3"/>, label: 'Sync CRM', onClick: () => openDetailedModal('SYNC', { label: 'Sync ICP → Salesforce' }) },
                      { icon: <Calendar className="w-3 h-3"/>, label: 'Revisão', onClick: () => openDetailedModal('SCHED', { label: 'Agendar Revisão de ICP' }) },
                    ]} />
                  </div>,
                  <div key="icp-c2" className="bg-white rounded-[24px] border border-slate-200 shadow-sm p-5 flex flex-col h-full space-y-3">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2"><Settings2 className="w-3 h-3 text-slate-500"/>Pesos do ICP</p>
                    <p className="text-[8px] text-slate-400">Ajuste os pesos — scores recalculados ao vivo.</p>
                    <div className="space-y-2">
                      {([
                        { label:'Receita Anual', key:'receita' as const, val: icpWeights.receita },
                        { label:'Stack Tecnológico', key:'stack' as const, val: icpWeights.stack },
                        { label:'Tamanho de Equipe', key:'equipe' as const, val: icpWeights.equipe },
                        { label:'Setor / Vertical', key:'setor' as const, val: icpWeights.setor },
                      ] as const).map((w) => (
                        <div key={w.key} className="space-y-0.5">
                          <div className="flex justify-between text-[9px] font-bold text-slate-500 uppercase"><span>{w.label}</span><span className="text-slate-700">{w.val}%</span></div>
                          <input type="range" min="0" max="50" value={w.val}
                            onChange={e => setIcpWeights(prev => ({ ...prev, [w.key]: Number(e.target.value) }))}
                            className="w-full h-1.5 accent-slate-600 rounded-full cursor-pointer"/>
                        </div>
                      ))}
                    </div>
                    <button onClick={() => openDetailedModal('CONFIG', { label: 'Config Pesos ICP', weights: icpWeights })} className="w-full py-2.5 bg-slate-900 hover:bg-black text-white text-[9px] font-bold uppercase rounded-xl transition-colors">Salvar Configuração</button>
                    <MiniActions actions={[
                      { icon: <History className="w-3 h-3"/>, label: 'Histórico', onClick: () => openDetailedModal('HIST', { label: 'Histórico de Configs' }) },
                      { icon: <Share2 className="w-3 h-3"/>, label: 'Compartilhar', onClick: () => openDetailedModal('SHARE', { label: 'Compartilhar Config' }) },
                      { icon: <Bell className="w-3 h-3"/>, label: 'Alertas', onClick: () => openDetailedModal('ALERT', { label: 'Alertas de ICP' }) },
                    ]} />
                  </div>,

                  <div key="icp-c3" className="bg-white rounded-[24px] border border-slate-200 shadow-sm p-5 flex flex-col h-full space-y-3">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2"><Bot className="w-3 h-3 text-emerald-500"/>IA Lookalike</p>
                    <p className="text-[8px] text-slate-400 leading-relaxed">Encontre contas gemêas baseadas nas TOP 10% qualificadas no ICP atual.</p>
                    <div className="p-3 bg-emerald-50 border border-emerald-100 rounded-xl flex items-center gap-3">
                       <Bot className="w-5 h-5 text-emerald-600"/>
                       <div>
                         <p className="text-[10px] font-bold text-slate-800">42 Contas Descobertas</p>
                         <p className="text-[8px] text-emerald-600 font-bold uppercase">Sinergia &gt; 85% com o tier 1</p>
                       </div>
                    </div>
                    <button onClick={() => openDetailedModal('LOOKALIKE', { label: 'Gerar Lista IA Lookalike' })} className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-[9px] font-bold uppercase rounded-xl transition-colors mt-2">Importar do Canopi Intel</button>
                    <MiniActions actions={[
                      { icon: <Search className="w-3 h-3"/>, label: 'Refinar IA', onClick: () => openDetailedModal('REFINE_IA', { label: 'Refinar Parâmetros de IA' }) },
                      { icon: <Database className="w-3 h-3"/>, label: 'Enriquecer', onClick: () => openDetailedModal('ENR_IA', { label: 'Enriquecer via Claro/BDR' }) },
                      { icon: <Share2 className="w-3 h-3"/>, label: 'Enviar Vendas', onClick: () => openDetailedModal('SEND_SALES', { label: 'Enviar Lista para SDR' }) },
                    ]} />
                  </div>,
                ],
                ct: [
                  <div key="ct-c1" className="bg-white rounded-[24px] border border-slate-200 shadow-sm p-5 flex flex-col h-full space-y-3">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widests flex items-center gap-2"><Users className="w-3 h-3 text-indigo-500"/>Gap de Contatos (DMU)</p>
                    <div className="space-y-1.5">
                      {abmHeatmapAccounts.filter(a => a.ct < 50 && a.imp > 60).slice(0,4).map(acc => (
                        <div key={acc.id} className="flex items-center gap-2 p-2.5 bg-amber-50 border border-amber-100 rounded-xl">
                          <AlertCircle className="w-3 h-3 text-amber-500 shrink-0"/>
                          <div className="flex-1 min-w-0"><p className="text-[9px] font-bold text-slate-800 truncate">{acc.name}</p><p className="text-[8px] text-slate-400">{acc.ct}% mapeado</p></div>
                          <button onClick={() => openDetailedModal('ENRICH', acc)} className="text-[8px] bg-indigo-600 text-white px-2 py-1 rounded-lg font-bold hover:bg-indigo-700 transition-colors shrink-0">Enriquecer</button>
                        </div>
                      ))}
                    </div>
                    <button onClick={() => openDetailedModal('LINKEDIN', { label: 'LinkedIn Sales Navigator' })} className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-[9px] font-bold uppercase rounded-xl transition-colors flex items-center justify-center gap-2">
                      <ExternalLink className="w-3 h-3"/>LinkedIn Sales Nav
                    </button>
                    <MiniActions actions={[
                      { icon: <Database className="w-3 h-3"/>, label: 'Atual. CRM', onClick: () => openDetailedModal('CRM_UPDATE', { label: 'Atualizar Contatos no CRM' }) },
                      { icon: <CheckCircle className="w-3 h-3"/>, label: 'Atribuir', onClick: () => openDetailedModal('ASSIGN', { label: 'Atribuir SDR por Conta' }) },
                      { icon: <Smartphone className="w-3 h-3"/>, label: 'Canopi', onClick: () => openDetailedModal('CANOPI', { label: 'Registrar no Canopi' }) },
                    ]} />
                  </div>,
                  <div key="ct-c2" className="bg-white rounded-[24px] border border-slate-200 shadow-sm p-5 flex flex-col h-full space-y-3">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2"><BadgeCheck className="w-3 h-3 text-emerald-500"/>Cargos Críticos DMU</p>
                    <div className="space-y-1.5">
                      {[
                        { cargo:'CEO / Presidente', status:'gap', pct:38 },
                        { cargo:'CFO / Dir. Finanças', status:'gap', pct:42 },
                        { cargo:'CTO / Dir. TI', status:'ok', pct:78 },
                        { cargo:'VP Comercial', status:'gap', pct:30 },
                        { cargo:'Head de Produto', status:'ok', pct:65 },
                      ].map((c, i) => (
                        <div key={i} className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-slate-50 cursor-pointer" onClick={() => openDetailedModal('ROLE', c)}>
                          <div className={`w-2 h-2 rounded-full shrink-0 ${c.status === 'ok' ? 'bg-emerald-400' : 'bg-red-400'}`}/>
                          <span className="text-[9px] font-medium text-slate-600 flex-1">{c.cargo}</span>
                          <span className={`text-[9px] font-bold ${c.status === 'ok' ? 'text-emerald-600' : 'text-red-500'}`}>{c.pct}%</span>
                        </div>
                      ))}
                    </div>
                    <button onClick={() => openDetailedModal('SEQ', { label: 'Sequência por Cargo' })} className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-[9px] font-bold uppercase rounded-xl transition-colors">Criar Sequência por Cargo</button>
                    <MiniActions actions={[
                      { icon: <Mail className="w-3 h-3"/>, label: 'Campanha', onClick: () => openDetailedModal('CAMP', { label: 'Campanha por Cargo' }) },
                      { icon: <Calendar className="w-3 h-3"/>, label: 'Atividade', onClick: () => openDetailedModal('ACTIVITY', { label: 'Atribuir Atividade Canopi' }) },
                      { icon: <MessageSquare className="w-3 h-3"/>, label: 'Conectar', onClick: () => openDetailedModal('CONNECT', { label: 'Conectar no LinkedIn' }) },
                    ]} />
                  </div>,

                  <div key="ct-c3" className="bg-white rounded-[24px] border border-slate-200 shadow-sm p-5 flex flex-col h-full space-y-3">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2"><Map className="w-3 h-3 text-blue-500"/>Mapa de Influência</p>
                    <p className="text-[8px] text-slate-400 leading-relaxed">Identifique os bloqueadores e campeões dentro dos comitês mapeados.</p>
                    <div className="grid grid-cols-2 gap-2">
                       <div className="p-2 border border-slate-100 rounded-lg text-center bg-slate-50"><p className="text-[12px] font-black text-blue-600">14</p><p className="text-[7px] font-bold text-slate-500 uppercase mt-0.5">Champions</p></div>
                       <div className="p-2 border border-slate-100 rounded-lg text-center bg-slate-50"><p className="text-[12px] font-black text-amber-500">8</p><p className="text-[7px] font-bold text-slate-500 uppercase mt-0.5">Bloqueadores</p></div>
                    </div>
                    <button onClick={() => openDetailedModal('INFLUENCE_MAP', { label: 'Extrair Mapa de Influência' })} className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-[9px] font-bold uppercase rounded-xl transition-colors mt-2">Mapear Conexões</button>
                    <MiniActions actions={[
                      { icon: <Share2 className="w-3 h-3"/>, label: 'Social Selling', onClick: () => openDetailedModal('SS', { label: 'Rede de Contatos - Social Selling' }) },
                      { icon: <TrendingUp className="w-3 h-3"/>, label: 'Evolução', onClick: () => openDetailedModal('MAP_EVO', { label: 'Evolução do Comitê' }) },
                      { icon: <Zap className="w-3 h-3"/>, label: 'Ação C-Level', onClick: () => openDetailedModal('CLEVEL_PLAY', { label: 'Abordagem Executiva' }) },
                    ]} />
                  </div>,
                ],
                ft: [
                  <div key="ft-c1" className="bg-white rounded-[24px] border border-slate-200 shadow-sm p-5 flex flex-col h-full space-y-3">
                    <div className="flex items-center justify-between">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2"><ArrowUpRight className="w-3 h-3 text-emerald-500"/>Fast-Track Pipeline</p>
                      <Badge variant="emerald" className="text-[8px] border-none bg-emerald-50 text-emerald-600 font-bold">{abmHeatmapAccounts.filter(a=>a.ft>=75).length} elegíveis</Badge>
                    </div>
                    <div className="space-y-1.5">
                      {abmHeatmapAccounts.filter(a => a.ft >= 75).slice(0,4).map(acc => (
                        <div key={acc.id} className="flex items-center justify-between p-2.5 bg-emerald-50 border border-emerald-100 rounded-xl group cursor-pointer hover:border-emerald-300 transition-all" onClick={() => openDetailedModal('ACCOUNT', acc)}>
                          <div><p className="text-[9px] font-bold text-slate-800">{acc.name}</p><p className="text-[8px] text-emerald-600">Fit {acc.ft}% — Budget R${acc.budget}k</p></div>
                          <button onClick={e => { e.stopPropagation(); openDetailedModal('MOVE', { label: `Mover ${acc.name} → Oportunidade` }); }} className="text-[8px] bg-emerald-600 text-white px-2 py-1 rounded-lg font-bold opacity-0 group-hover:opacity-100 transition-opacity">Mover</button>
                        </div>
                      ))}
                    </div>
                    <button onClick={() => openDetailedModal('FAST_TRACK', { label: 'Mover Elegíveis → Oportunidade' })} className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-[9px] font-bold uppercase rounded-xl transition-colors">Mover Todas para Oportunidade</button>
                    <MiniActions actions={[
                      { icon: <FileText className="w-3 h-3"/>, label: 'Proposta', onClick: () => openDetailedModal('PROP', { label: 'Criar Proposta Comercial' }) },
                      { icon: <Calendar className="w-3 h-3"/>, label: 'Demo', onClick: () => openDetailedModal('DEMO', { label: 'Marcar Demo' }) },
                      { icon: <Database className="w-3 h-3"/>, label: 'Criar Oport.', onClick: () => openDetailedModal('OPP', { label: 'Criar Oportunidade CRM' }) },
                    ]} />
                  </div>,
                  <div key="ft-c2" className="bg-white rounded-[24px] border border-slate-200 shadow-sm p-5 flex flex-col h-full space-y-3">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2"><BarChart3 className="w-3 h-3 text-blue-500"/>Análise de Gaps de Fit</p>
                    <div className="space-y-2">
                      {[
                        { label:'Stack Tecnológico', val:72, color:'bg-blue-500' },
                        { label:'Maturidade Analítica', val:58, color:'bg-indigo-500' },
                        { label:'Timing Comercial', val:44, color:'bg-amber-500' },
                        { label:'Cultura de Dados', val:35, color:'bg-red-500' },
                      ].map((g, i) => (
                        <div key={i} className="space-y-0.5 cursor-pointer" onClick={() => openDetailedModal('GAP', g)}>
                          <div className="flex justify-between text-[9px] font-bold text-slate-500 uppercase"><span>{g.label}</span><span>{g.val}%</span></div>
                          <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden"><div className={`h-full ${g.color} rounded-full`} style={{ width: `${g.val}%` }}/></div>
                        </div>
                      ))}
                    </div>
                    <button onClick={() => openDetailedModal('ROADMAP', { label: 'Roadmap de Fit' })} className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-[9px] font-bold uppercase rounded-xl transition-colors">Propor Roadmap de Fit</button>
                    <MiniActions actions={[
                      { icon: <Mail className="w-3 h-3"/>, label: 'Campanha Fit', onClick: () => openDetailedModal('CAMP', { label: 'Campanha de Fit Tecnológico' }) },
                      { icon: <Users className="w-3 h-3"/>, label: 'Workshop', onClick: () => openDetailedModal('EVENT', { label: 'Workshop de Maturidade' }) },
                      { icon: <FileText className="w-3 h-3"/>, label: 'Case Study', onClick: () => openDetailedModal('CASE', { label: 'Enviar Case de Sucesso' }) },
                    ]} />
                  </div>,

                  <div key="ft-c3" className="bg-white rounded-[24px] border border-slate-200 shadow-sm p-5 flex flex-col h-full space-y-3">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2"><Cpu className="w-3 h-3 text-amber-500"/>Sinais Tecnológicos</p>
                    <p className="text-[8px] text-slate-400 leading-relaxed">Contas indicando mudanças de infraestrutura ou adoção de concorrentes.</p>
                    <div className="space-y-1.5">
                       {[{name: 'TechInsure Co.', signal:'Pesquisa Cloud AWS'},{name:'ScalePay Brasil', signal:'Fim contratação Hubspot'}].map((a, i) => (
                         <div key={i} className="p-2 bg-amber-50 rounded-lg">
                           <p className="text-[9px] font-bold text-slate-800">{a.name}</p>
                           <p className="text-[8px] text-amber-600 uppercase font-bold mt-0.5"><Zap className="inline w-2 h-2 mr-1"/>{a.signal}</p>
                         </div>
                       ))}
                    </div>
                    <button onClick={() => openDetailedModal('INTENT', { label: 'Sinais de Intenção Totais' })} className="w-full py-2.5 bg-amber-500 hover:bg-amber-600 text-white text-[9px] font-bold uppercase rounded-xl transition-colors mt-2">Monitorar Concorrentes</button>
                    <MiniActions actions={[
                      { icon: <Search className="w-3 h-3"/>, label: 'Tech Stack', onClick: () => openDetailedModal('TECH_STACK', { label: 'Scrape de Tecnologias' }) },
                      { icon: <Database className="w-3 h-3"/>, label: 'Alerta CRM', onClick: () => openDetailedModal('CRM_ALERT', { label: 'Criar Alerta SDR CRM' }) },
                      { icon: <Users className="w-3 h-3"/>, label: 'G2 / Capterra', onClick: () => openDetailedModal('G2_INTENT', { label: 'Analisar Intent G2' }) },
                    ]} />
                  </div>,
                ],
                crm: [
                  <div key="crm-c1" className="bg-white rounded-[24px] border border-slate-200 shadow-sm p-5 flex flex-col h-full space-y-3">
                    <div className="flex items-center justify-between">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2"><Activity className="w-3 h-3 text-blue-500"/>Contas Quentes</p>
                      <span className="w-5 h-5 rounded-full bg-red-500 text-white text-[9px] font-bold flex items-center justify-center">{hotCrm.length}</span>
                    </div>
                    <div className="space-y-1.5">
                      {hotCrm.slice(0,3).map(acc => (
                        <div key={acc.id} className="p-2.5 bg-blue-50 border border-blue-100 rounded-xl">
                          <div className="flex items-center justify-between mb-1.5">
                            <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse shrink-0"/><p className="text-[9px] font-bold text-slate-800 truncate max-w-[90px]">{acc.name}</p></div>
                            <span className="text-[8px] font-bold text-blue-700">{acc.crm}%</span>
                          </div>
                          <div className="flex gap-1">
                            {[
                              { label:'SDR', color:'bg-blue-600 hover:bg-blue-700', type:'SDR' },
                              { label:'AE / Vendas', color:'bg-indigo-600 hover:bg-indigo-700', type:'AE' },
                              { label:'Campanha', color:'bg-purple-600 hover:bg-purple-700', type:'CAMP' },
                            ].map(b => (
                              <button key={b.type} onClick={() => openDetailedModal(b.type, { label: `${b.label}: ${acc.name}`, account: acc })} className={`flex-1 text-[7px] ${b.color} text-white py-1 rounded-lg font-bold transition-colors`}>{b.label}</button>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                    <button onClick={() => openDetailedModal('SEQ', { label: 'Sequência Multicanal — Contas Quentes' })} className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-[9px] font-bold uppercase rounded-xl transition-colors">Criar Sequência Multicanal</button>
                    <MiniActions actions={[
                      { icon: <ArrowUpRight className="w-3 h-3"/>, label: 'Oportunidade', onClick: () => openDetailedModal('OPP', { label: 'Criar Oportunidade no CRM' }) },
                      { icon: <Calendar className="w-3 h-3"/>, label: 'Atividade', onClick: () => openDetailedModal('ACTIVITY', { label: 'Atribuir Atividade Canopi' }) },
                      { icon: <Database className="w-3 h-3"/>, label: 'Atual. CRM', onClick: () => openDetailedModal('CRM_UPDATE', { label: 'Atualizar Status CRM' }) },
                    ]} />
                  </div>,
                  <div key="crm-c2" className="bg-white rounded-[24px] border border-slate-200 shadow-sm p-5 flex flex-col h-full space-y-3">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2"><Bell className="w-3 h-3 text-amber-500"/>Reativação de Frias</p>
                    <div className="space-y-1.5">
                      {coldCrm.slice(0,4).map(acc => (
                        <div key={acc.id} className="flex items-center gap-2 p-2.5 bg-slate-50 border border-slate-100 rounded-xl">
                          <div className="w-2 h-2 rounded-full bg-slate-300 shrink-0"/>
                          <div className="flex-1 min-w-0"><p className="text-[9px] font-bold text-slate-800 truncate">{acc.name}</p><p className="text-[8px] text-slate-400">{acc.crm}% engaj. — {acc.vertical}</p></div>
                          <button onClick={() => openDetailedModal('REACTIVATE', acc)} className="text-[8px] bg-amber-500 text-white px-2 py-1 rounded-lg font-bold hover:bg-amber-600 transition-colors shrink-0">Reativar</button>
                        </div>
                      ))}
                    </div>
                    <button onClick={() => openDetailedModal('CAMP_REACT', { label: 'Campanha de Reengajamento' })} className="w-full py-2.5 bg-amber-500 hover:bg-amber-600 text-white text-[9px] font-bold uppercase rounded-xl transition-colors">Lançar Campanha Reengajamento</button>
                    <MiniActions actions={[
                      { icon: <Mail className="w-3 h-3"/>, label: 'Email Flow', onClick: () => openDetailedModal('EMAIL', { label: 'Fluxo E-mail Reativação' }) },
                      { icon: <Eye className="w-3 h-3"/>, label: 'Diagnóstico', onClick: () => openDetailedModal('DIAG', { label: 'Diagnóstico de Churn Risk' }) },
                      { icon: <ZapOff className="w-3 h-3"/>, label: 'Pausar', onClick: () => openDetailedModal('PAUSE', { label: 'Pausar Contas Inativas' }) },
                    ]} />
                  </div>,

                  <div key="crm-c3" className="bg-white rounded-[24px] border border-slate-200 shadow-sm p-5 flex flex-col h-full space-y-3">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2"><Target className="w-3 h-3 text-emerald-500"/>Velocidade do Pipeline</p>
                    <p className="text-[8px] text-slate-400 leading-relaxed">Dias médios na fase atual de contas mapeadas vs contas ignoradas.</p>
                    <div className="flex items-end gap-3 h-16 mt-2 pt-2 border-t border-slate-50">
                       <div className="flex-1 bg-slate-100 rounded-t-lg h-full flex items-center justify-center flex-col"><p className="text-[11px] font-black">28</p><p className="text-[6px] text-slate-400 uppercase font-bold">Inativo</p></div>
                       <div className="flex-1 bg-emerald-500 rounded-t-lg h-[45%] flex items-center justify-center flex-col text-white"><p className="text-[11px] font-black">12</p><p className="text-[6px] text-emerald-100 uppercase font-bold">ABM</p></div>
                    </div>
                    <button onClick={() => openDetailedModal('VELOCITY', { label: 'Dashboard de Análise de Pipeline' })} className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-[9px] font-bold uppercase rounded-xl transition-colors mt-2">Analisar Gargalos</button>
                    <MiniActions actions={[
                      { icon: <History className="w-3 h-3"/>, label: 'Histórico', onClick: () => openDetailedModal('HIST_PIPE', { label: 'Histórico de Conversões' }) },
                      { icon: <Activity className="w-3 h-3"/>, label: 'Forecasting', onClick: () => openDetailedModal('FORECAST', { label: 'Forecasting ABM' }) },
                      { icon: <Share2 className="w-3 h-3"/>, label: 'RevOps', onClick: () => openDetailedModal('REVOPS', { label: 'Ajuste de SLA RevOps' }) },
                    ]} />
                  </div>,
                ],
                vp: [
                  <div key="vp-c1" className="bg-white rounded-[24px] border border-slate-200 shadow-sm p-5 flex flex-col h-full space-y-3">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2"><PieChart className="w-3 h-3 text-purple-500"/>Budget Mapeado (Contexto)</p>
                    <p className="text-[8px] text-slate-400 leading-relaxed">Budget ABM real extraído do histórico da base de clientes por setor. Pool total identificado: <span className="font-bold text-slate-700">R$480k</span></p>
                    <div className="space-y-1.5 pt-1">
                      {([
                        { label:'Financeiro', pct:35, color:'bg-blue-600' },
                        { label:'Saúde', pct:20, color:'bg-emerald-600' },
                        { label:'Agronegócio', pct:18, color:'bg-lime-600' },
                        { label:'Telecom', pct:15, color:'bg-indigo-600' },
                        { label:'Outros', pct:12, color:'bg-slate-400' },
                      ] as const).map(v => {
                        const rsk = Math.round(480 * v.pct / 100);
                        return (
                          <div key={v.label} className="flex items-center justify-between p-2 bg-slate-50 rounded-lg">
                             <div className="flex items-center gap-2">
                                <span className={`w-2 h-2 rounded-full ${v.color}`}></span>
                                <span className="text-[9px] font-bold text-slate-700 uppercase">{v.label}</span>
                             </div>
                             <span className="text-[10px] font-black text-purple-700">R${rsk}k <span className="text-[8px] text-slate-400 opacity-60">({v.pct}%)</span></span>
                          </div>
                        );
                      })}
                    </div>
                    <button onClick={() => openDetailedModal('REP', { label: 'Análise Profunda de Budget Setorial' })} className="w-full py-2.5 bg-purple-600 hover:bg-purple-700 text-white text-[9px] font-bold uppercase rounded-xl transition-colors mt-2">Explorar Dados Financeiros</button>
                    <MiniActions actions={[
                      { icon: <FileText className="w-3 h-3"/>, label: 'Exportar PDF', onClick: () => openDetailedModal('REP_PDF', { label: 'Exportar PDF de Budget' }) },
                      { icon: <Flag className="w-3 h-3"/>, label: 'Alocar Verba', onClick: () => openDetailedModal('FUND', { label: 'Alocar Verba no Canopi' }) },
                      { icon: <Users className="w-3 h-3"/>, label: 'Compartilhar', onClick: () => openDetailedModal('SHARE_BUDGET', { label: 'Compartilhar C-Level' }) },
                    ]} />
                  </div>,
                  <div key="vp-c2" className="bg-white rounded-[24px] border border-slate-200 shadow-sm p-5 flex flex-col h-full space-y-3">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2"><Box className="w-3 h-3 text-indigo-500"/>Criar Cluster ABM</p>
                    <div className="space-y-2">
                      <div>
                        <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1">Nome do Cluster</label>
                        <input type="text" placeholder="Ex: Fintech High Growth" className="w-full text-[10px] border border-slate-200 rounded-xl px-3 py-2 focus:outline-none focus:border-blue-400 text-slate-700 font-medium"/>
                      </div>
                      <div>
                        <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1">Vertical Alvo</label>
                        <select className="w-full text-[10px] border border-slate-200 rounded-xl px-3 py-2 focus:outline-none focus:border-blue-400 text-slate-700 font-medium bg-white">
                          {['Financeiro','Saúde','Agronegócio','Telecom','Indústria','Mobilidade','Seguros','Varejo','Educação','Construção','Energia'].map(v => <option key={v}>{v}</option>)}
                        </select>
                      </div>
                      <div>
                        <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1">Score Mínimo de Vertical</label>
                        <input type="range" min="40" max="90" defaultValue="65" className="w-full h-1.5 accent-indigo-600 rounded-full cursor-pointer"/>
                      </div>
                    </div>
                    <button onClick={() => openDetailedModal('CREATE_CLUSTER', { label: 'Criar Cluster de Vertical' })} className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-[9px] font-bold uppercase rounded-xl transition-colors flex items-center justify-center gap-2"><Plus className="w-3 h-3"/>Criar Cluster</button>
                    <MiniActions actions={[
                      { icon: <Users className="w-3 h-3"/>, label: 'Ver Contas', onClick: () => openDetailedModal('CLUSTER_ACCS', { label: 'Contas por Vertical' }) },
                      { icon: <Mail className="w-3 h-3"/>, label: 'Play', onClick: () => openDetailedModal('PLAY', { label: 'Executar Play de Vertical' }) },
                      { icon: <Crosshair className="w-3 h-3"/>, label: 'Segmentar', onClick: () => openDetailedModal('SEG', { label: 'Criar Segmento por Vertical' }) },
                    ]} />
                  </div>,

                  <div key="vp-c3" className="bg-white rounded-[24px] border border-slate-200 shadow-sm p-5 flex flex-col h-full space-y-3">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2"><Globe className="w-3 h-3 text-blue-500"/>Eventos & Relacionamento</p>
                    <p className="text-[8px] text-slate-400 leading-relaxed">Orquestração offline para clusters de altíssimo valor (Eventos, Jantares).</p>
                    <div className="space-y-1.5 pt-1">
                       {[{name:'Jantar C-Level', date:'12 Nov, SP', cluster:'Fintech Top'},{name:'Workshop Tech', date:'20 Nov, Online', cluster:'Saúde Mid'}].map((e,i) => (
                         <div key={i} className="flex justify-between items-center bg-slate-50 p-2 rounded-lg">
                            <div><p className="text-[9px] font-bold text-slate-800">{e.name}</p><p className="text-[7px] font-bold text-blue-500 uppercase">{e.cluster}</p></div>
                            <span className="text-[8px] font-bold text-slate-400 text-right">{e.date}</span>
                         </div>
                       ))}
                    </div>
                    <button onClick={() => openDetailedModal('EVENT_ROI', { label: 'Gestão de Eventos ABM' })} className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-[9px] font-bold uppercase rounded-xl transition-colors mt-2">Planejar Evento Regional</button>
                    <MiniActions actions={[
                      { icon: <Mail className="w-3 h-3"/>, label: 'RSVP', onClick: () => openDetailedModal('RSVP', { label: 'Gestão de RSVP VIP' }) },
                      { icon: <Users className="w-3 h-3"/>, label: 'Presentes', onClick: () => openDetailedModal('GIFT', { label: 'Enviar Direct Mail / Brinde' }) },
                      { icon: <Calendar className="w-3 h-3"/>, label: 'Executivo', onClick: () => openDetailedModal('EXEC_SYNC', { label: 'Alinhamento com Founders' }) },
                    ]} />
                  </div>,
                ],
              };


              return orderedCriteria.map((id) => {
                const criterion = criteriaMap[id];
                return (
                  <div key={criterion.id} className="grid grid-cols-1 xl:grid-cols-[58.5%_41.5%] gap-5 items-stretch">
                    {/* Heatmap card */}
                    <div className="bg-white p-8 rounded-[40px] border border-slate-200 shadow-sm flex flex-col h-full space-y-5">
                      {/* Header */}
                      <div className="flex justify-between items-center">
                        <div>
                          <h3 className="text-xl font-bold text-slate-900 uppercase">{criterion.title}</h3>
                          <p className="text-sm text-slate-500 font-medium mt-1">{criterion.subtitle}</p>
                        </div>
                        <div className="flex gap-3 items-center">
                          {[{c:'#27ae60',l:'Baixo'},{c:'#f9ca24',l:'Médio'},{c:'#e67e22',l:'Alto'},{c:'#c0392b',l:'Crítico'}].map(i=>(
                            <div key={i.l} className="flex items-center gap-1.5">
                              <div className="w-3 h-3 rounded-full" style={{backgroundColor:i.c}}></div>
                              <span className="text-[10px] font-bold text-slate-400 uppercase">{i.l}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    {/* SVG heatmap */}
                    <div className="rounded-3xl overflow-hidden border border-slate-100 shadow-inner flex-1 flex flex-col bg-slate-900/[0.02] items-center justify-center">
                      <svg
                        width="100%" height="100%"
                        viewBox="0 0 800 500"
                        preserveAspectRatio="xMidYMid meet"
                        style={{display:'block', cursor:'crosshair', minHeight: '400px'}}
                        onMouseLeave={() => setHmTooltip(null)}
                      >
                        <defs>
                          <linearGradient id={`hmGradFull-${criterion.id}`} x1="0%" y1="100%" x2="100%" y2="0%">
                            <stop offset="0%"   stopColor="#27ae60" stopOpacity="0.92" />
                            <stop offset="40%"  stopColor="#f9ca24" stopOpacity="0.92" />
                            <stop offset="70%"  stopColor="#e67e22" stopOpacity="0.92" />
                            <stop offset="100%" stopColor="#c0392b" stopOpacity="0.92" />
                          </linearGradient>
                        </defs>
                        <rect x="0" y="0" width="800" height="500" fill={`url(#hmGradFull-${criterion.id})`} />
                        {/* Grid lines 4x4 */}
                        {[1,2,3].map(i => <line key={`v${i}`} x1={i*200} y1="0" x2={i*200} y2="500" stroke="rgba(255,255,255,0.18)" strokeWidth="1" />)}
                        {[1,2,3].map(i => <line key={`h${i}`} x1="0" y1={i*125} x2="800" y2={i*125} stroke="rgba(255,255,255,0.18)" strokeWidth="1" />)}
                        {abmHeatmapAccounts.map((acc) => {
                          const score = criterion.scoreKey === 'icp' ? getWeightedIcp(acc) : getHmScore(acc, criterion.scoreKey);
                          const cx = 28 + (score / 100) * 744;
                          const cy = 470 - (acc.imp / 100) * 440;
                          const desc = criterion.desc(acc);

                          // Cor do número conforme temperatura (posição no gradiente diagonal)
                          const tempValue = (score + acc.imp) / 2;
                          const numColor = tempValue >= 78 ? '#c0392b' : tempValue >= 62 ? '#e67e22' : tempValue >= 46 ? '#b7860b' : '#1a7a3c';

                          // Label: mostra vertical no heatmap "vp", nome da empresa nos demais
                          const labelText = criterion.id === 'vp' ? acc.vertical : acc.name;
                          const shortLabel = labelText.length > 13 ? labelText.slice(0, 13) + '…' : labelText;
                          const labelW = Math.min(shortLabel.length * 5.5 + 12, 90);

                          // Alterna posição do callout (acima/abaixo) para minimizar sobreposição
                          const above = acc.id % 2 === 1;
                          const lineY1 = above ? cy - 12 : cy + 12;
                          const lineY2 = above ? cy - 28 : cy + 28;
                          const labelY = above ? lineY2 - 12 : lineY2 + 1;

                          return (
                            <g
                              key={acc.id}
                              style={{cursor:'pointer'}}
                              onMouseEnter={(e) => {
                                const rect = (e.currentTarget.closest('svg') as SVGSVGElement).getBoundingClientRect();
                                const svgX = (e.clientX - rect.left) * (800 / rect.width);
                                const svgY = (e.clientY - rect.top) * (500 / rect.height);
                                const displayName = criterion.id === 'vp' ? acc.vertical : acc.name;
                                setHmTooltip({ criterionId: criterion.id, x: svgX, y: svgY, displayName, name: acc.name, vertical: acc.vertical, score, desc });
                              }}
                              onMouseLeave={() => setHmTooltip(null)}
                            >
                              {/* Callout line */}
                              <line x1={cx} y1={lineY1} x2={cx} y2={lineY2} stroke="rgba(255,255,255,0.7)" strokeWidth="1" strokeDasharray="2,2" />
                              {/* Label pill */}
                              <rect x={cx - labelW / 2} y={above ? labelY - 10 : labelY} width={labelW} height={12} rx="4" fill="rgba(15,23,42,0.72)" />
                              <text x={cx} y={above ? labelY - 1 : labelY + 9} textAnchor="middle" fill="rgba(255,255,255,0.92)" fontSize="7" fontWeight="700" fontFamily="sans-serif">{shortLabel}</text>
                              {/* Bubble */}
                              <circle cx={cx} cy={cy} r="13" fill="rgba(255,255,255,0.95)" stroke="rgba(255,255,255,0.45)" strokeWidth="1.5" />
                              <circle cx={cx} cy={cy} r="10" fill="none" stroke="rgba(255,255,255,0.22)" strokeWidth="1" />
                              <text x={cx} y={cy + 3.5} textAnchor="middle" fill={numColor} fontSize="7.5" fontWeight="900" fontFamily="sans-serif">{score}%</text>
                            </g>
                          );
                        })}
                        {/* Axis labels */}
                        <text x="400" y="490" textAnchor="middle" fill="rgba(255,255,255,0.65)" fontSize="10" fontWeight="700" fontFamily="sans-serif" letterSpacing="3">{criterion.xLabel}</text>
                        <text x="14" y="250" textAnchor="middle" fill="rgba(255,255,255,0.65)" fontSize="10" fontWeight="700" fontFamily="sans-serif" letterSpacing="3" transform="rotate(-90,14,250)">{criterion.yLabel}</text>
                        {/* Tooltip — apenas para este heatmap */}
                        {hmTooltip && hmTooltip.criterionId === criterion.id && (() => {
                          const tipTemp = (hmTooltip.score + abmHeatmapAccounts.find(a => a.name === hmTooltip.name)!.imp) / 2;
                          const tipColor = tipTemp >= 78 ? '#e74c3c' : tipTemp >= 62 ? '#f39c12' : tipTemp >= 46 ? '#d4ac0d' : '#27ae60';
                          return (
                            <g transform={`translate(${Math.min(hmTooltip.x + 14, 610)}, ${hmTooltip.y > 380 ? hmTooltip.y - 130 : hmTooltip.y + 14})`}>
                              <rect x="0" y="0" width="190" height="118" rx="10" fill="rgba(15,23,42,0.97)" />
                              <text x="12" y="22" fill="white" fontSize="12" fontWeight="700" fontFamily="sans-serif">{hmTooltip.displayName}</text>
                              <text x="12" y="36" fill="#94a3b8" fontSize="9" fontFamily="sans-serif">{criterion.id === 'vp' ? hmTooltip.name : hmTooltip.vertical}</text>
                              <rect x="12" y="43" width="166" height="1" fill="rgba(255,255,255,0.1)" />
                              <text x="12" y="62" fill={tipColor} fontSize="17" fontWeight="900" fontFamily="sans-serif">{hmTooltip.score}%</text>
                              {hmTooltip.desc.slice(hmTooltip.desc.indexOf('—') + 2).match(/.{1,33}/g)?.slice(0,3).map((line, i) => (
                                <text key={i} x="12" y={78 + i * 13} fill="#cbd5e1" fontSize="9" fontFamily="sans-serif">{line}</text>
                              ))}
                            </g>
                          );
                        })()}
                      </svg>
                    </div>
                    {/* Disclaimer */}
                    <p className="text-[10px] text-slate-400 font-medium leading-relaxed pt-3 px-1 border-t border-slate-50 mt-2">
                      <span className="font-bold text-slate-500 uppercase tracking-wide mr-1">Como ler:</span>{criterion.note}
                    </p>
                  </div>
                  {/* Action cards — grid 2x2 perfeitamente simétrico */}
                  <div className="grid grid-cols-2 grid-rows-[1fr_1fr] gap-4 h-full">
                    {(actionCards[criterion.id] || []).map((card, i) => (
                      <div key={i} className={i === 2 ? "col-span-2 h-full" : "col-span-1 h-full"}>
                        {card}
                      </div>
                    ))}
                  </div>
                </div>
                );
              });
            })()}

           {/* HEXBIN — MATRIZ DE RESSONÂNCIA (Organic multi-hotspot) */}
           <div className="bg-white p-10 rounded-[40px] border border-slate-200 shadow-sm space-y-8">
              <div className="flex justify-between items-center border-b border-slate-100 pb-8">
                 <div>
                    <h3 className="text-xl font-bold text-slate-900 uppercase">Matriz de Ressonância HEX-BIN</h3>
                    <p className="text-sm text-slate-500 font-medium mt-1">Sinergia de Persona (cargo) x Vertical de mercado — intensidade de contato e conversão</p>
                 </div>
                 <div className="flex items-center gap-4">
                    <span className="text-[10px] font-bold text-slate-400 uppercase bg-slate-50 px-4 py-2 rounded-xl">{hexVerticals.length} Verticais</span>
                    <span className="text-[10px] font-bold text-slate-400 uppercase bg-slate-50 px-4 py-2 rounded-xl">{personas.length} Personas</span>
                 </div>
              </div>

              <div className="flex gap-6 items-start overflow-x-auto pb-2">
                 {/* Y-axis persona labels */}
                 <div className="flex flex-col justify-start gap-0 pt-10 shrink-0">
                    {personas.map((p, i) => (
                      <div key={i} className="h-[44px] flex items-center">
                        <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wide text-right" style={{ width: 120 }}>{p}</span>
                      </div>
                    ))}
                 </div>

                 {/* Hex grid */}
                 <div className="flex flex-col gap-0">
                    {/* X-axis vertical labels */}
                    <div className="flex gap-0 mb-1 pl-3">
                      {hexVerticals.map((v, ci) => (
                        <div key={ci} style={{ width: 44 }} className="text-[8px] font-bold text-slate-400 uppercase text-center leading-tight truncate">{v}</div>
                      ))}
                    </div>
                    {/* Hexagonal rows */}
                    {personas.map((persona, ri) => (
                      <div key={ri} className="flex">
                        {hexVerticals.map((vertical, ci) => {
                          const intensity = hexIntensityMap[`${ri},${ci}`] ?? 0.3;
                          const color = getHexCellColor(intensity);
                          const score = Math.round(intensity * 100);
                          return (
                            <div
                              key={ci}
                              title={`${persona} x ${vertical}: ${score}%`}
                              onClick={() => openDetailedModal('HEX_CELL', { persona, vertical, score, channel: channelByIntensity(intensity), intensity })}
                              style={{
                                width: 40, height: 40,
                                clipPath: 'polygon(50% 0%, 93% 25%, 93% 75%, 50% 100%, 7% 75%, 7% 25%)',
                                backgroundColor: color,
                                margin: '2px',
                                cursor: 'pointer',
                                transition: 'filter 0.2s, transform 0.2s',
                              }}
                              className="hover:brightness-110 hover:scale-110 active:scale-95"
                            />
                          );
                        })}
                      </div>
                    ))}
                 </div>

                 {/* Color scale legend — vertical, right side */}
                 <div className="flex flex-col items-center gap-1 pt-10 shrink-0 ml-4">
                    <span className="text-[8px] font-bold text-slate-400 uppercase mb-1">Alta</span>
                    {['#c0392b','#e74c3c','#e67e22','#f39c12','#f9ca24','#a8e6cf','#27ae60','#2ecc71','#1abc9c'].reverse().map((c, i) => (
                      <div key={i} className="w-5 rounded" style={{ height: 20, backgroundColor: c }}></div>
                    ))}
                    <span className="text-[8px] font-bold text-slate-400 uppercase mt-1">Baixa</span>
                 </div>
              </div>

              <div className="pt-6 border-t border-slate-100 flex flex-wrap gap-6 items-center">
                 <div className="flex gap-6">
                    {[
                      { color: '#c0392b', label: 'Sinergia Muito Alta (80-100)' },
                      { color: '#f39c12', label: 'Sinergia Moderada (50-80)' },
                      { color: '#27ae60', label: 'Sinergia Baixa (< 50)' },
                    ].map(l => (
                      <div key={l.label} className="flex items-center gap-2">
                        <div className="w-4 h-4 rounded-sm" style={{ backgroundColor: l.color }}></div>
                        <span className="text-[9px] font-bold text-slate-500 uppercase">{l.label}</span>
                      </div>
                    ))}
                 </div>
                 <Badge variant="blue" className="ml-auto bg-blue-50 text-blue-600 border-none text-[10px] font-bold uppercase px-4 py-1.5">Resonancy Score: 1:54</Badge>
              </div>
           </div>

      {/* ===== FIT FIRMOGRÁFICO + TECNOGRÁFICO (abaixo dos heatmaps) ===== */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* FIT FIRMOGRÁFICO */}
        <div className="bg-white p-8 rounded-[32px] border border-slate-200 shadow-sm space-y-6">
          <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2"><Globe className="w-3 h-3"/> Fit Firmográfico ABM</h4>
          <div className="space-y-5">
            {[
              { label: 'Receita Anual (> R$ 500M)', val: 78 },
              { label: 'Sede (SP / Remoto)', val: 92 },
              { label: 'Tamanho Time Tech (> 50)', val: 45 }
            ].map((idx, i) => (
              <div key={i} className="space-y-2">
                <div className="flex justify-between text-[9px] font-bold text-slate-600 uppercase"><span>{idx.label}</span><span>{idx.val}%</span></div>
                <div className="h-1.5 w-full bg-slate-50 rounded-full overflow-hidden border border-slate-100">
                  <div className="h-full bg-blue-600" style={{ width: `${idx.val}%` }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>
        {/* FIT TECNOGRÁFICO */}
        <div className="bg-white p-8 rounded-[32px] border border-slate-200 shadow-sm space-y-6">
          <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2"><Cpu className="w-3 h-3"/> Fit Tecnográfico ABM</h4>
          <div className="space-y-3">
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 flex items-center gap-3 group cursor-pointer hover:border-blue-300 transition-all" onClick={() => openDetailedModal('TECH', { label: 'Stack Cloud' })}>
              <Cloud className="w-4 h-4 text-blue-600" />
              <div className="flex-1"><p className="text-[10px] font-bold text-slate-900 uppercase tracking-tight">Stack Cloud</p><p className="text-[9px] font-bold text-slate-400 uppercase">AWS / Azure Dominante</p></div>
              <ChevronRight className="w-3 h-3 text-slate-300 group-hover:text-blue-600" />
            </div>
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 flex items-center gap-3 group cursor-pointer hover:border-blue-300 transition-all" onClick={() => openDetailedModal('TECH', { label: 'CRM' })}>
              <Database className="w-4 h-4 text-blue-600" />
              <div className="flex-1"><p className="text-[10px] font-bold text-slate-900 uppercase tracking-tight">CRM Utilizado</p><p className="text-[9px] font-bold text-slate-400 uppercase">Salesforce (85%)</p></div>
              <ChevronRight className="w-3 h-3 text-slate-300 group-hover:text-blue-600" />
            </div>
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 flex items-center gap-3 group cursor-pointer hover:border-blue-300 transition-all" onClick={() => openDetailedModal('TECH', { label: 'AI Readiness' })}>
              <Sparkles className="w-4 h-4 text-blue-600" />
              <div className="flex-1"><p className="text-[10px] font-bold text-slate-900 uppercase tracking-tight">AI Readiness</p><p className="text-[9px] font-bold text-slate-400 uppercase">Alta Maturidade</p></div>
              <ChevronRight className="w-3 h-3 text-slate-300 group-hover:text-blue-600" />
            </div>
          </div>
        </div>
      </div>

      {/* 3. PLAYS DE ENTRADA RECOMENDADOS (RESTORED) */}
      <div className="bg-white p-10 rounded-[40px] border border-slate-200 shadow-sm space-y-10">
         <div className="flex justify-between items-center bg-white">
            <div>
               <h3 className="text-xl font-bold text-slate-900 uppercase">Plays de Entrada Recomendados</h3>
               <p className="text-sm text-slate-500 font-medium mt-1">Ações táticas validadas para os clusters ativos</p>
            </div>
            <Button variant="ghost" className="text-[10px] font-bold text-blue-600 uppercase tracking-widest border border-blue-100 px-6 py-2 rounded-xl">Ver Todos os Playbooks</Button>
         </div>
         <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {entryPlays.map((play) => (
               <motion.div key={play.id} whileHover={{ y: -8 }} className="bg-white border border-slate-100 p-8 rounded-[32px] shadow-sm hover:shadow-xl hover:border-blue-400 transition-all flex flex-col h-full group">
                  <div className="w-14 h-14 bg-slate-50 rounded-2xl flex items-center justify-center text-blue-600 mb-6 group-hover:bg-blue-600 group-hover:text-white transition-all shadow-inner relative overflow-hidden">
                     <div className="absolute inset-0 opacity-10 group-hover:opacity-20 transition-opacity">
                        <Sparkles className="w-full h-full p-2" />
                     </div>
                     {play.icon}
                  </div>
                  <h4 className="text-lg font-bold text-slate-900 mb-4 uppercase tracking-tight leading-tight">{play.title}</h4>
                  <p className="text-sm text-slate-500 font-medium leading-relaxed mb-8 flex-1">{play.desc}</p>
                  <div className="pt-6 border-t border-slate-100 flex justify-between items-center">
                     <div><p className="text-[9px] font-bold text-slate-400 uppercase mb-1">Eficácia</p><p className="text-sm font-bold text-slate-900 tracking-tighter">{play.efficacy}%</p></div>
                     <Button className="bg-slate-900 text-white font-bold rounded-xl text-[10px] uppercase py-3 px-6 hover:bg-black border-none" onClick={() => openDetailedModal('PLAY', play)}>Executar Play</Button>
                  </div>
               </motion.div>
            ))}
         </div>
      </div>

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title={modalData?.title || 'Canopi ABM Intelligence'}>
        <div className="py-2">{modalData?.content}</div>
      </Modal>

    </div>
  );
};

// --- HELPER COMPONENTS ---

const Circle: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10" strokeWidth="2" /></svg>
);

const Hexagon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z" /></svg>
);

export default ABMStrategy;
